using System;
namespace Meftah.Core.Commands
{
    public class DelegateCommand : IEditorCommand
    {
        private readonly Action _do, _undo;
        public string Description { get; }
        public DelegateCommand(string desc, Action doAction, Action undoAction)
        { Description=desc; _do=doAction; _undo=undoAction; }
        public void Execute() => _do();
        public void Undo() => _undo();
    }
}