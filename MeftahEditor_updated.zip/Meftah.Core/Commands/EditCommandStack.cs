using System;
using System.Collections.Generic;
namespace Meftah.Core.Commands
{
    public class EditCommandStack
    {
        private readonly Stack<IEditorCommand> _undo = new();
        private readonly Stack<IEditorCommand> _redo = new();
        public bool CanUndo => _undo.Count > 0;
        public bool CanRedo => _redo.Count > 0;
        public event Action? Changed;
        public void Execute(IEditorCommand cmd) { cmd.Execute(); _undo.Push(cmd); _redo.Clear(); Changed?.Invoke(); }
        public void Undo() { if(!CanUndo) return; var c=_undo.Pop(); c.Undo(); _redo.Push(c); Changed?.Invoke(); }
        public void Redo() { if(!CanRedo) return; var c=_redo.Pop(); c.Execute(); _undo.Push(c); Changed?.Invoke(); }
        public void Clear() { _undo.Clear(); _redo.Clear(); Changed?.Invoke(); }
    }
}