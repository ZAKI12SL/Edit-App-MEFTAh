using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
namespace Meftah.Core.Services
{
    public class RecentProjectsService
    {
        private readonly string _filePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "MeftahEditor", "recent.json");
        private const int Max = 10;

        public List<string> Load()
        {
            try
            {
                if (!File.Exists(_filePath)) return new();
                return JsonSerializer.Deserialize<List<string>>(File.ReadAllText(_filePath)) ?? new();
            }
            catch { return new(); }
        }

        public void Add(string path)
        {
            var list = Load();
            list.Remove(path);
            list.Insert(0, path);
            if (list.Count > Max) list.RemoveRange(Max, list.Count - Max);
            Directory.CreateDirectory(Path.GetDirectoryName(_filePath)!);
            File.WriteAllText(_filePath, JsonSerializer.Serialize(list));
        }
    }
}