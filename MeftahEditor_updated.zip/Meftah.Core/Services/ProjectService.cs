using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Meftah.Core.Commands;
using Meftah.Core.Models;
namespace Meftah.Core.Services
{
    public class ProjectService
    {
        public ProjectSettings Settings { get; private set; } = new();
        public Timeline Timeline { get; } = new();
        public ObservableCollection<MediaItem> MediaBin { get; } = new();
        public EditCommandStack CommandStack { get; } = new();
        public string? CurrentPath { get; private set; }
        private static readonly JsonSerializerOptions Opts = new() { WriteIndented = true };

        public void NewProject()
        {
            Settings = new ProjectSettings();
            Timeline.Clear();
            MediaBin.Clear();
            CommandStack.Clear();
            CurrentPath = null;
            AddDefaultTracks();
        }

        public void AddDefaultTracks()
        {
            Timeline.AddTrack(new VideoTrack { Name = "V1" });
            Timeline.AddTrack(new VideoTrack { Name = "V2" });
            Timeline.AddTrack(new AudioTrack { Name = "A1" });
            Timeline.AddTrack(new AudioTrack { Name = "A2" });
        }

        public void AddMedia(MediaItem item)
        {
            MediaBin.Add(item);
        }

        public async Task SaveAsync(string path)
        {
            var model = new SaveModel { Settings = Settings, MediaBin = new(MediaBin), Tracks = new(Timeline.Tracks), Markers = new(Timeline.Markers) };
            await File.WriteAllTextAsync(path, JsonSerializer.Serialize(model, Opts));
            CurrentPath = path;
        }

        public async Task LoadAsync(string path)
        {
            var json = await File.ReadAllTextAsync(path);
            var model = JsonSerializer.Deserialize<SaveModel>(json, Opts) ?? new();
            Settings = model.Settings ?? new();
            Timeline.Clear(); MediaBin.Clear(); CommandStack.Clear();
            foreach (var m in model.MediaBin ?? new()) MediaBin.Add(m);
            foreach (var t in model.Tracks ?? new()) Timeline.AddTrack(t);
            foreach (var mk in model.Markers ?? new()) Timeline.Markers.Add(mk);
            CurrentPath = path;
        }
    }

    public class SaveModel
    {
        public ProjectSettings? Settings { get; set; }
        public System.Collections.Generic.List<MediaItem>? MediaBin { get; set; }
        public System.Collections.Generic.List<Track>? Tracks { get; set; }
        public System.Collections.Generic.List<Marker>? Markers { get; set; }
    }
}