using System;
using System.IO;
using CommunityToolkit.Mvvm.ComponentModel;
namespace Meftah.Core.Models
{
    public partial class MediaItem : ObservableObject
    {
        [ObservableProperty] private string _filePath = string.Empty;
        [ObservableProperty] private TimeSpan _duration;
        [ObservableProperty] private string _mediaType = string.Empty;
        [ObservableProperty] private string _thumbnailPath = string.Empty;

        // ---- عناصر مُولَّدة (غير مرتبطة بملف على القرص) ----
        // تُنشأ من قائمة كليك يمين في Media Library: New Text / New Shape /
        // New Path / New Adjustment Layer / New Color Matte. IsSynthetic تميّزها
        // عن العناصر المستوردة من ملفات حقيقية، وSyntheticKind يحفظ نوعها
        // لعرض شارة مناسبة ولحساب رقمها التسلسلي (Text 01, Text 02...).
        [ObservableProperty] private bool _isSynthetic;
        [ObservableProperty] private string _syntheticKind = string.Empty;
        [ObservableProperty] private string _colorHex = "#3B82F6";

        public string FileName => Path.GetFileName(FilePath);
        public bool IsAudio => MediaType is ".MP3" or ".WAV" or ".AAC" or ".FLAC";
        public bool IsVideo => !IsAudio;
    }
}