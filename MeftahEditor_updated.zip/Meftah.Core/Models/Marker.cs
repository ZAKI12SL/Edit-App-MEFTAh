using System;
using CommunityToolkit.Mvvm.ComponentModel;
namespace Meftah.Core.Models
{
    public partial class Marker : ObservableObject
    {
        [ObservableProperty] private Guid _id = Guid.NewGuid();
        [ObservableProperty] private TimeSpan _time;
        [ObservableProperty] private string _label = "Marker";
        [ObservableProperty] private string _colorHex = "#F59E0B";
    }
}