using System;
using System.Collections.ObjectModel;
using System.Text.Json.Serialization;
using CommunityToolkit.Mvvm.ComponentModel;
using Meftah.Core.Models.Audio;

namespace Meftah.Core.Models
{
    [JsonDerivedType(typeof(VideoTrack), "video")]
    [JsonDerivedType(typeof(AudioTrack), "audio")]
    public abstract partial class Track : ObservableObject
    {
        [ObservableProperty] private Guid _id = Guid.NewGuid();
        [ObservableProperty] private string _name = "Track";
        [ObservableProperty] private bool _isLocked;
        [ObservableProperty] private bool _isHidden;
        [ObservableProperty] private bool _isMuted;
        [ObservableProperty] private bool _isSolo;
        [ObservableProperty] private double _volume = 1.0;
        [ObservableProperty] private double _pan;

        /// سلسلة مؤثرات الصوت الخاصة بكامل المسار — تُطبَّق بعد مؤثرات كل مقطع
        /// (تماماً كما في Audio Track Mixer داخل Premiere Pro).
        public ObservableCollection<AudioEffectBase> EffectsChain { get; } = new();

        public ObservableCollection<Clip> Clips { get; } = new();
        public void AddClip(Clip c) => Clips.Add(c);
        public void RemoveClip(Clip c) => Clips.Remove(c);
        public void RippleShift(TimeSpan after, TimeSpan delta)
        {
            foreach (var c in Clips)
                if (c.Start >= after)
                    c.Start = c.Start + delta < TimeSpan.Zero ? TimeSpan.Zero : c.Start + delta;
        }
    }
    public partial class VideoTrack : Track { public VideoTrack() => Name = "Video"; }
    public partial class AudioTrack : Track { public AudioTrack() => Name = "Audio"; }
}
