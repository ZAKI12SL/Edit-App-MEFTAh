using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
namespace Meftah.Core.Models
{
    public class Timeline
    {
        public ObservableCollection<Track> Tracks { get; } = new();
        public ObservableCollection<Marker> Markers { get; } = new();
        public void AddTrack(Track t) => Tracks.Add(t);
        public void RemoveTrack(Track t) => Tracks.Remove(t);
        public void Clear() { Tracks.Clear(); Markers.Clear(); }
        public IEnumerable<Clip> AllClips() => Tracks.SelectMany(t => t.Clips);
        public IEnumerable<Clip> SelectedClips() => AllClips().Where(c => c.IsSelected);
        public void ClearSelection() { foreach (var c in AllClips()) c.IsSelected = false; }
        public TimeSpan TotalDuration() => AllClips().Any() ? AllClips().Max(c => c.End) : TimeSpan.Zero;
    }
}