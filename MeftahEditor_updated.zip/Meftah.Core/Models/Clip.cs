using System;
using System.Collections.ObjectModel;
using System.Text.Json.Serialization;
using CommunityToolkit.Mvvm.ComponentModel;
using Meftah.Core.Models.Audio;

namespace Meftah.Core.Models
{
    [JsonDerivedType(typeof(VideoClip), "video")]
    [JsonDerivedType(typeof(AudioClip), "audio")]
    public abstract partial class Clip : ObservableObject
    {
        [ObservableProperty] private Guid _id = Guid.NewGuid();
        [ObservableProperty] private string _name = "Clip";
        [ObservableProperty] private TimeSpan _start;
        [ObservableProperty] private TimeSpan _duration = TimeSpan.FromSeconds(5);

        /// نقطة البداية داخل ملف المصدر نفسه (in-point) — تتغيّر عند قصّ الحافة
        /// اليسرى للمقطع في التايم لاين، بحيث يُعرَض/يُصدَّر الجزء الصحيح من
        /// المصدر وليس بدايته دائماً.
        [ObservableProperty] private TimeSpan _sourceIn;
        [ObservableProperty] private string _colorHex = "#3B82F6";
        [ObservableProperty] private MediaItem _source = new();
        [JsonIgnore][ObservableProperty] private bool _isSelected;

        // ---- خصائص الصوت المشتركة (لمقاطع الفيديو وأصوات مقاطع الصوت المستقلة) ----
        [ObservableProperty] private double _volume = 1.0; // 1.0 = 0dB
        [ObservableProperty] private double _pan;            // -100..100
        [ObservableProperty] private bool _isMuted;

        /// سلسلة مؤثرات الصوت الخاصة بهذا المقطع (Amplify, EQ, Reverb, Delay...)
        /// تُطبَّق بالترتيب من الأعلى إلى الأسفل قبل مؤثرات المسار.
        public ObservableCollection<AudioEffectBase> EffectsChain { get; private set; } = new();

        public TimeSpan End => Start + Duration;

        public Clip ShallowClone()
        {
            var c = (Clip)MemberwiseClone();
            c._id = Guid.NewGuid();
            c._isSelected = false;
            // سلسلة المؤثرات مرجع (reference) وليست قيمة، لذا يجب استنساخها بشكل
            // مستقل هنا وإلا ستتشارك النسخة الأصلية والمكررة نفس القائمة.
            c.EffectsChain = new ObservableCollection<AudioEffectBase>();
            foreach (var fx in EffectsChain) c.EffectsChain.Add(fx.Clone());
            return c;
        }
    }

    public partial class VideoClip : Clip
    {
        [ObservableProperty] private double _speed = 1.0;
        [ObservableProperty] private double _opacity = 1.0;
        [ObservableProperty] private bool _flipH;
        [ObservableProperty] private bool _flipV;
        [ObservableProperty] private double _rotation;
        public VideoClip() => ColorHex = "#2563EB";
    }

    public partial class AudioClip : Clip
    {
        public AudioClip() => ColorHex = "#059669";
    }
}
