namespace Meftah.Core.Models
{
    public class ProjectSettings
    {
        public string Name { get; set; } = "Untitled Project";
        public int Width { get; set; } = 1920;
        public int Height { get; set; } = 1080;
        public double FrameRate { get; set; } = 30.0;
        public string OutputFolder { get; set; } = string.Empty;
        public string LastSavedPath { get; set; } = string.Empty;
    }
}