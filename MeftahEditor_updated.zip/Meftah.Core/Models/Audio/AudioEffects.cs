using CommunityToolkit.Mvvm.ComponentModel;

namespace Meftah.Core.Models.Audio
{
    // هذا الملف يحتوي المجموعة الأولى من مؤثرات الصوت — وهي المؤثرات التي
    // تملك معالجة صوت (DSP) حقيقية وفعّالة في Meftah.Engine.AudioEffectChainBuilder.
    // مؤثرات إضافية (Chorus, Flanger, Pitch Shifter, DeNoise, DeHummer...)
    // ستُضاف في مرحلة لاحقة بعد ربطها بمعالج DSP حقيقي — لا فائدة من إضافة
    // مؤثر يظهر في الواجهة ولا يغيّر الصوت فعلياً.

    // ===== Amplitude and Compression =====

    /// Amplify — رفع أو خفض مستوى صوت المقطع بالكامل
    public partial class AmplifyEffect : AudioEffectBase
    {
        [ObservableProperty] private double _gainDb; // -96..+24 dB
        public override string DisplayName => "Amplify";
        public override AudioEffectBase Clone() => new AmplifyEffect { GainDb = GainDb, IsEnabled = IsEnabled };
    }

    /// Dynamics — يجمع Compressor وLimiter وNoise Gate داخل مؤثر واحد
    public partial class DynamicsEffect : AudioEffectBase
    {
        [ObservableProperty] private bool _compressorEnabled = true;
        [ObservableProperty] private double _thresholdDb = -18;
        [ObservableProperty] private double _ratio = 3;      // 1..20
        [ObservableProperty] private double _attackMs = 10;
        [ObservableProperty] private double _releaseMs = 100;
        [ObservableProperty] private double _makeupGainDb;

        [ObservableProperty] private bool _limiterEnabled;
        [ObservableProperty] private double _limiterCeilingDb = -0.3;

        [ObservableProperty] private bool _noiseGateEnabled;
        [ObservableProperty] private double _gateThresholdDb = -50;

        public override string DisplayName => "Dynamics";
        public override AudioEffectBase Clone() => new DynamicsEffect
        {
            CompressorEnabled = CompressorEnabled, ThresholdDb = ThresholdDb, Ratio = Ratio,
            AttackMs = AttackMs, ReleaseMs = ReleaseMs, MakeupGainDb = MakeupGainDb,
            LimiterEnabled = LimiterEnabled, LimiterCeilingDb = LimiterCeilingDb,
            NoiseGateEnabled = NoiseGateEnabled, GateThresholdDb = GateThresholdDb, IsEnabled = IsEnabled
        };
    }

    // ===== Filter & EQ =====

    /// Parametric Equalizer — ثلاث نطاقات (Low Shelf / Mid Peak / High Shelf)
    public partial class ParametricEqEffect : AudioEffectBase
    {
        [ObservableProperty] private double _lowShelfFreq = 200;
        [ObservableProperty] private double _lowShelfGainDb;
        [ObservableProperty] private double _midFreq = 1000;
        [ObservableProperty] private double _midGainDb;
        [ObservableProperty] private double _midQ = 1.0;
        [ObservableProperty] private double _highShelfFreq = 5000;
        [ObservableProperty] private double _highShelfGainDb;
        public override string DisplayName => "Parametric EQ";
        public override AudioEffectBase Clone() => new ParametricEqEffect
        {
            LowShelfFreq = LowShelfFreq, LowShelfGainDb = LowShelfGainDb, MidFreq = MidFreq,
            MidGainDb = MidGainDb, MidQ = MidQ, HighShelfFreq = HighShelfFreq,
            HighShelfGainDb = HighShelfGainDb, IsEnabled = IsEnabled
        };
    }

    /// Bass — تقوية أو خفض الترددات المنخفضة فقط
    public partial class BassEffect : AudioEffectBase
    {
        [ObservableProperty] private double _boostDb;
        [ObservableProperty] private double _frequency = 200;
        public override string DisplayName => "Bass";
        public override AudioEffectBase Clone() => new BassEffect { BoostDb = BoostDb, Frequency = Frequency, IsEnabled = IsEnabled };
    }

    /// Treble — تقوية أو خفض الترددات العالية فقط
    public partial class TrebleEffect : AudioEffectBase
    {
        [ObservableProperty] private double _boostDb;
        [ObservableProperty] private double _frequency = 4000;
        public override string DisplayName => "Treble";
        public override AudioEffectBase Clone() => new TrebleEffect { BoostDb = BoostDb, Frequency = Frequency, IsEnabled = IsEnabled };
    }

    /// Highpass — حذف الترددات المنخفضة عن نقطة معينة
    public partial class HighpassEffect : AudioEffectBase
    {
        [ObservableProperty] private double _cutoffFrequency = 100;
        public override string DisplayName => "Highpass";
        public override AudioEffectBase Clone() => new HighpassEffect { CutoffFrequency = CutoffFrequency, IsEnabled = IsEnabled };
    }

    /// Lowpass — حذف الترددات العالية عن نقطة معينة
    public partial class LowpassEffect : AudioEffectBase
    {
        [ObservableProperty] private double _cutoffFrequency = 8000;
        public override string DisplayName => "Lowpass";
        public override AudioEffectBase Clone() => new LowpassEffect { CutoffFrequency = CutoffFrequency, IsEnabled = IsEnabled };
    }

    // ===== Noise Reduction =====

    /// Noise Gate — كتم الصوت تلقائياً عندما ينخفض عن مستوى معين
    public partial class NoiseGateEffect : AudioEffectBase
    {
        [ObservableProperty] private double _thresholdDb = -40;
        [ObservableProperty] private double _attackMs = 2;
        [ObservableProperty] private double _releaseMs = 150;
        public override string DisplayName => "Noise Gate";
        public override AudioEffectBase Clone() => new NoiseGateEffect { ThresholdDb = ThresholdDb, AttackMs = AttackMs, ReleaseMs = ReleaseMs, IsEnabled = IsEnabled };
    }

    // ===== Delay & Echo =====

    /// Delay — تكرار الصوت بعد فترة زمنية محددة مع تغذية راجعة (Feedback)
    public partial class DelayEffect : AudioEffectBase
    {
        [ObservableProperty] private double _delayMs = 350;
        [ObservableProperty] private double _feedback = 30; // %
        [ObservableProperty] private double _mix = 50;        // %
        public override string DisplayName => "Delay";
        public override AudioEffectBase Clone() => new DelayEffect { DelayMs = DelayMs, Feedback = Feedback, Mix = Mix, IsEnabled = IsEnabled };
    }

    /// Echo — صدى أوضح وأبطأ من الـDelay العادي
    public partial class EchoEffect : AudioEffectBase
    {
        [ObservableProperty] private double _delayMs = 500;
        [ObservableProperty] private double _decay = 50; // %
        [ObservableProperty] private double _mix = 50;    // %
        public override string DisplayName => "Echo";
        public override AudioEffectBase Clone() => new EchoEffect { DelayMs = DelayMs, Decay = Decay, Mix = Mix, IsEnabled = IsEnabled };
    }

    // ===== Reverb =====

    /// Reverb — محاكاة انعكاس الصوت داخل غرفة (Schroeder Reverb مبسّط)
    public partial class ReverbEffect : AudioEffectBase
    {
        [ObservableProperty] private double _roomSize = 50; // %
        [ObservableProperty] private double _damping = 50;  // %
        [ObservableProperty] private double _mix = 30;        // %
        public override string DisplayName => "Reverb";
        public override AudioEffectBase Clone() => new ReverbEffect { RoomSize = RoomSize, Damping = Damping, Mix = Mix, IsEnabled = IsEnabled };
    }

    // ===== Stereo Imaging =====

    /// Balance — تحريك الصوت بين اليمين واليسار (Equal-Power Pan)
    public partial class BalanceEffect : AudioEffectBase
    {
        [ObservableProperty] private double _pan; // -100..100
        public override string DisplayName => "Balance";
        public override AudioEffectBase Clone() => new BalanceEffect { Pan = Pan, IsEnabled = IsEnabled };
    }
}
