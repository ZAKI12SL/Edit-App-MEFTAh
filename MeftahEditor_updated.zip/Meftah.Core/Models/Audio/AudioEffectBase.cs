using System;
using CommunityToolkit.Mvvm.ComponentModel;
using System.Text.Json.Serialization;

namespace Meftah.Core.Models.Audio
{
    /// <summary>
    /// القاعدة المشتركة لكل مؤثرات الصوت (Audio Effects) في مفتاح.
    /// كل صنف هنا هو "معاملات" فقط (Parameters) قابلة للتسلسل (Serialization)
    /// وربطها بالواجهة مباشرة — أما المعالجة الفعلية للصوت (DSP) فتتم في
    /// طبقة Meftah.Engine (راجع AudioEffectChainBuilder) حتى تبقى طبقة الـCore
    /// خفيفة ولا تعتمد على مكتبة NAudio.
    ///
    /// سمات JsonDerivedType ضرورية هنا حتى يستطيع System.Text.Json حفظ/تحميل
    /// سلسلة المؤثرات (EffectsChain) بنوعها الحقيقي داخل ملف المشروع (.meftah)
    /// بدل أن يفقد خصائص كل مؤثر عند الحفظ.
    /// </summary>
    [JsonDerivedType(typeof(AmplifyEffect), "amplify")]
    [JsonDerivedType(typeof(DynamicsEffect), "dynamics")]
    [JsonDerivedType(typeof(ParametricEqEffect), "parametricEq")]
    [JsonDerivedType(typeof(BassEffect), "bass")]
    [JsonDerivedType(typeof(TrebleEffect), "treble")]
    [JsonDerivedType(typeof(HighpassEffect), "highpass")]
    [JsonDerivedType(typeof(LowpassEffect), "lowpass")]
    [JsonDerivedType(typeof(NoiseGateEffect), "noiseGate")]
    [JsonDerivedType(typeof(DelayEffect), "delay")]
    [JsonDerivedType(typeof(EchoEffect), "echo")]
    [JsonDerivedType(typeof(ReverbEffect), "reverb")]
    [JsonDerivedType(typeof(BalanceEffect), "balance")]
    public abstract partial class AudioEffectBase : ObservableObject
    {
        [ObservableProperty] private Guid _id = Guid.NewGuid();
        [ObservableProperty] private bool _isEnabled = true;

        /// اسم المؤثر كما يظهر في نافذة Effect Controls / Essential Sound
        public abstract string DisplayName { get; }

        /// نسخة مستقلة من المؤثر (تُستخدم عند نسخ/تكرار مقطع مع مؤثراته)
        public abstract AudioEffectBase Clone();
    }
}

