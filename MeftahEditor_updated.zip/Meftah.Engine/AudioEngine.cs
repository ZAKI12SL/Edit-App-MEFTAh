using System;
using Meftah.Core.Models;
using Meftah.Core.Models.Audio;
using Meftah.Engine.Audio;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace Meftah.Engine
{
    /// <summary>
    /// محرك تشغيل الصوت للمعاينة والاستماع (Audition). يبني سلسلة معالجة
    /// حقيقية (مؤثرات المقطع → حجم/توازن المقطع → مؤثرات المسار → حجم/توازن
    /// المسار) ويشغّلها عبر NAudio، مع توفير قياس مستوى حي (Peak Meter)
    /// لاستخدامه في Audio Track Mixer.
    ///
    /// ملاحظة صريحة حول حدود هذا الإصدار: هذا محرك تشغيل مقطع واحد للمعاينة
    /// (Audition) — مزج كل مسارات التايم لاين معاً في وقت واحد ومتزامنة مع
    /// الفيديو هو مرحلة تالية، وتحتاج استبدال محرك المعاينة الحالي
    /// (WPF MediaElement) بمحرك عرض/تشغيل مخصص، وهي خطوة أكبر تم تأجيلها
    /// عمداً بعد هذا المعلم (milestone) حسب الأولوية التي تم الاتفاق عليها.
    /// </summary>
    public class AudioEngine : IDisposable
    {
        private WaveOutEvent? _output;
        private AudioFileReader? _reader;
        private MeteringSampleProvider? _meter;

        public bool IsPlaying => _output?.PlaybackState == PlaybackState.Playing;

        /// يُطلَق بشكل دوري أثناء التشغيل بقيم الذروة (0..1) لكل من القناة اليسرى واليمنى
        public event Action<float, float>? LevelsChanged;

        /// تحميل مقطع للمعاينة مع تطبيق كامل سلسلة المؤثرات الخاصة به وبمساره
        public void LoadForAudition(string filePath, Clip? clip = null, Track? track = null)
        {
            Stop();
            _reader = new AudioFileReader(filePath);
            ISampleProvider chain = _reader;

            if (chain.WaveFormat.Channels == 1)
                chain = new MonoToStereoSampleProvider(chain);

            // ---- سلسلة مؤثرات المقطع + حجمه وتوازنه ----
            if (clip != null)
            {
                if (clip.EffectsChain.Count > 0)
                    chain = AudioEffectChainBuilder.Build(chain, clip.EffectsChain);

                chain = new BalanceProvider(chain, new BalanceEffect { Pan = clip.Pan });
                chain = new VolumeSampleProvider(chain) { Volume = clip.IsMuted ? 0f : (float)clip.Volume };
            }

            // ---- سلسلة مؤثرات المسار + حجمه وتوازنه وكتمه ----
            if (track != null)
            {
                if (track.EffectsChain.Count > 0)
                    chain = AudioEffectChainBuilder.Build(chain, track.EffectsChain);

                chain = new BalanceProvider(chain, new BalanceEffect { Pan = track.Pan });
                chain = new VolumeSampleProvider(chain) { Volume = track.IsMuted ? 0f : (float)track.Volume };
            }

            _meter = new MeteringSampleProvider(chain);
            _meter.StreamVolume += (_, e) => LevelsChanged?.Invoke(
                e.MaxSampleValues.Length > 0 ? e.MaxSampleValues[0] : 0,
                e.MaxSampleValues.Length > 1 ? e.MaxSampleValues[1] : 0);

            _output = new WaveOutEvent();
            _output.Init(_meter);
        }

        /// توافقاً مع الاستخدام القديم — تحميل ملف مباشرة بدون سلسلة مؤثرات
        public void Load(string path) => LoadForAudition(path);

        public void Play() => _output?.Play();
        public void Pause() => _output?.Pause();
        public void Stop()
        {
            _output?.Stop();
            _output?.Dispose();
            _reader?.Dispose();
            _output = null;
            _reader = null;
            _meter = null;
        }
        public void Dispose() => Stop();
    }
}
