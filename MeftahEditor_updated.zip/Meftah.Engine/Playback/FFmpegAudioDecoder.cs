using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;
using NAudio.Wave;

namespace Meftah.Engine.Playback
{
    /// <summary>
    /// يشغّل ffmpeg كعملية فرعية لفك ترميز الصوت المصاحب للفيديو وإخراجه
    /// كـPCM خام (16-bit / 44.1kHz / Stereo) عبر stdout، ثم يغلّفه كـ
    /// RawSourceWaveStream من NAudio ليصبح جاهزاً للتشغيل مباشرة عبر WaveOutEvent.
    /// </summary>
    public sealed class FFmpegAudioDecoder : IDisposable
    {
        public static readonly WaveFormat Format = new(44100, 16, 2);

        private readonly Process _process;
        public RawSourceWaveStream WaveStream { get; }

        private FFmpegAudioDecoder(Process process)
        {
            _process = process;
            WaveStream = new RawSourceWaveStream(process.StandardOutput.BaseStream, Format);
        }

        /// يعيد null إن لم يوجد مسار صوت في الملف — لا داعي لتشغيل عملية ffmpeg إضافية بلا فائدة
        public static FFmpegAudioDecoder? Start(string filePath, TimeSpan startAt, bool hasAudio)
        {
            if (!hasAudio) return null;
            if (!FFmpegLocator.IsAvailable)
                throw new InvalidOperationException(
                    "تعذّر إيجاد FFmpeg. ضع ffmpeg.exe داخل مجلد \"ffmpeg\" بجانب البرنامج، أو أضفه إلى PATH.");

            var ss = startAt.TotalSeconds.ToString(CultureInfo.InvariantCulture);
            var args = $"-ss {ss} -i \"{filePath}\" -f s16le -ar {Format.SampleRate} -ac {Format.Channels} " +
                       $"-vn -loglevel error pipe:1";

            var psi = new ProcessStartInfo
            {
                FileName = FFmpegLocator.FFmpegPath!,
                Arguments = args,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            };

            var process = Process.Start(psi);
            if (process == null) return null;
            Task.Run(() => { try { process.StandardError.BaseStream.CopyTo(Stream.Null); } catch { } });
            return new FFmpegAudioDecoder(process);
        }

        public void Dispose()
        {
            try { WaveStream.Dispose(); } catch { }
            try { if (!_process.HasExited) _process.Kill(entireProcessTree: true); } catch { }
            _process.Dispose();
        }
    }
}
