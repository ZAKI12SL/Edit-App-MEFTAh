using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Meftah.Core.Models;
using NAudio.Wave;

namespace Meftah.Engine.Playback
{
    /// <summary>
    /// محرك تشغيل مبني بالكامل على FFmpeg (بدل WPF MediaElement) لملف وسائط
    /// واحد يُعرض في Program Monitor. يدير: فك ترميز الفيديو (إطارات BGRA
    /// خام)، فك ترميز الصوت (PCM عبر NAudio)، وتزامنهما (Audio/Video Sync) —
    /// الصوت هو "الساعة الرئيسية" (Master Clock) وتتبعه معدلات عرض الفيديو،
    /// تماماً كما تعمل أغلب مشغلات الفيديو الاحترافية.
    ///
    /// حدود هذا الإصدار (صريحة): هذا محرك معاينة لملف واحد يُحمَّل يدوياً
    /// (بنقر مزدوج من Media Bin)، وليس محرك تركيب (Compositing) لكامل
    /// التايم لاين متعدد المسارات — ذلك معلم لاحق أكبر (Program Monitor
    /// Compositing Engine).
    /// </summary>
    public sealed class MediaPlaybackEngine : IDisposable
    {
        private FFmpegVideoDecoder? _video;
        private FFmpegAudioDecoder? _audio;
        private WaveOutEvent? _audioOutput;
        private Thread? _videoThread;
        private volatile bool _running;
        private volatile bool _paused = true;
        private readonly Stopwatch _clock = new();
        private TimeSpan _clockOffset;
        private string? _currentPath;

        public TimeSpan Duration { get; private set; }
        public bool HasAudio { get; private set; }
        public bool IsLoaded { get; private set; }
        public bool IsPlaying => _running && !_paused;

        /// يُطلَق من خيط الفيديو الداخلي — يجب أن يُعالَج المستمع بشكل متزامن
        /// (Dispatcher.Invoke وليس BeginInvoke) لأن نفس المخزن المؤقت (buffer)
        /// يُعاد استخدامه للإطار التالي فور عودة هذا الحدث.
        public event Action<byte[], int, int>? FrameReady;
        public event Action<TimeSpan>? PositionChanged;
        public event Action? PlaybackEnded;
        public event Action<string>? ErrorOccurred;

        public async Task LoadAsync(MediaItem item)
        {
            Stop();
            _currentPath = item.FilePath;
            var probe = await FFprobeHelper.ProbeAsync(item.FilePath);
            Duration = probe.Duration;
            HasAudio = probe.HasAudio;
            IsLoaded = true;
            StartDecodersAt(TimeSpan.Zero, probe);
        }

        private MediaProbeResult _probe;

        private void StartDecodersAt(TimeSpan position, MediaProbeResult? probe = null)
        {
            if (probe.HasValue) _probe = probe.Value;
            if (_currentPath == null) return;

            _video = FFmpegVideoDecoder.Start(_currentPath, _probe.Width, _probe.Height, _probe.FrameRate, position);
            _audio = HasAudio ? FFmpegAudioDecoder.Start(_currentPath, position, HasAudio) : null;

            if (_audio != null)
            {
                _audioOutput = new WaveOutEvent();
                _audioOutput.Init(_audio.WaveStream);
            }

            _clockOffset = position;
            _clock.Reset();
            _running = true;
            _paused = true; // يبدأ متوقفاً مؤقتاً حتى استدعاء Play()

            _videoThread = new Thread(VideoLoop) { IsBackground = true, Name = "Meftah-FFmpeg-VideoLoop" };
            _videoThread.Start();
        }

        private TimeSpan GetClock()
        {
            if (_audio != null && _audioOutput != null)
            {
                long bytes = _audioOutput.GetPosition();
                double seconds = bytes / (double)FFmpegAudioDecoder.Format.AverageBytesPerSecond;
                return _clockOffset + TimeSpan.FromSeconds(seconds);
            }
            return _clockOffset + (_paused ? TimeSpan.Zero : _clock.Elapsed);
        }

        private void VideoLoop()
        {
            var video = _video;
            if (video == null) return;
            double frameDuration = 1.0 / (video.FrameRate > 0 ? video.FrameRate : 30);
            int frameIndex = 0;
            // أول إطار يُعرَض فوراً بلا انتظار للساعة ولا لضغط Play — يعمل كـ
            // "صورة ثابتة" (poster frame) عند التحميل أو البحث (Seek) حتى لو
            // بقي التشغيل متوقفاً مؤقتاً. الإطارات اللاحقة تلتزم بالمزامنة
            // الطبيعية مع الساعة كما كانت.
            bool firstFrameShown = false;

            while (_running)
            {
                if (_paused && firstFrameShown) { Thread.Sleep(15); continue; }

                byte[]? frame;
                try { frame = video.ReadNextFrame(); }
                catch (Exception ex) { ErrorOccurred?.Invoke(ex.Message); break; }

                if (frame == null)
                {
                    // لو لم يُنتَج ولا إطار واحد، هذا فشل حقيقي في ffmpeg نفسه
                    // (كودك غير مدعوم، فلتر غير متاح، مسار خاطئ...) وليس مجرد
                    // نهاية طبيعية للمقطع — أبلِغ عن نص الخطأ الحقيقي من ffmpeg
                    // بدل ترك الشاشة سوداء بصمت تام كما كان يحدث سابقاً.
                    if (frameIndex == 0)
                    {
                        var err = video.LastErrorOutput.Trim();
                        ErrorOccurred?.Invoke(string.IsNullOrEmpty(err)
                            ? "لم يُنتِج ffmpeg أي إطار فيديو (تحقق من صيغة الملف/الكودك)."
                            : err);
                    }
                    _paused = true;
                    firstFrameShown = true;
                    PlaybackEnded?.Invoke();
                    continue;
                }

                var frameTime = _clockOffset + TimeSpan.FromSeconds(frameIndex * frameDuration);
                frameIndex++;

                if (firstFrameShown)
                {
                    // ننتظر حتى تصل الساعة الرئيسية (الصوت إن وُجد) لزمن هذا الإطار
                    while (_running && !_paused)
                    {
                        var clock = GetClock();
                        if (clock >= frameTime) break;
                        var wait = frameTime - clock;
                        Thread.Sleep(wait > TimeSpan.FromMilliseconds(20) ? 15 : 2);
                    }
                    if (!_running) break;
                }

                FrameReady?.Invoke(frame, video.Width, video.Height);
                PositionChanged?.Invoke(frameTime);
                firstFrameShown = true;
            }
        }

        public void Play()
        {
            if (!IsLoaded) return;
            if (!_paused) return;
            _paused = false;
            _clock.Restart();
            _audioOutput?.Play();
        }

        public void Pause()
        {
            if (_paused) return;
            _clockOffset = GetClock();
            _clock.Reset();
            _paused = true;
            _audioOutput?.Pause();
        }

        public void Seek(TimeSpan position)
        {
            if (!IsLoaded) return;
            bool wasPlaying = !_paused;
            StopDecodersOnly();
            StartDecodersAt(position);
            if (wasPlaying) Play();
        }

        private void StopDecodersOnly()
        {
            _running = false;
            _videoThread?.Join(500);
            _audioOutput?.Stop();
            _audioOutput?.Dispose();
            _audioOutput = null;
            _video?.Dispose();
            _video = null;
            _audio?.Dispose();
            _audio = null;
        }

        public void Stop()
        {
            StopDecodersOnly();
            _paused = true;
            _clockOffset = TimeSpan.Zero;
            _clock.Reset();
            IsLoaded = false;
        }

        public void Dispose() => Stop();
    }
}
