using System;
using System.Linq;
using System.Threading.Tasks;
using Xabe.FFmpeg;

namespace Meftah.Engine.Playback
{
    public readonly struct MediaProbeResult
    {
        public int Width { get; init; }
        public int Height { get; init; }
        public double FrameRate { get; init; }
        public TimeSpan Duration { get; init; }
        public bool HasVideo { get; init; }
        public bool HasAudio { get; init; }
    }

    /// <summary>
    /// يستخرج معلومات الملف اللازمة لبدء التشغيل (الأبعاد، معدل الإطارات،
    /// المدة، ووجود صوت من عدمه) عبر ffprobe (من خلال Xabe.FFmpeg).
    /// </summary>
    public static class FFprobeHelper
    {
        public static async Task<MediaProbeResult> ProbeAsync(string filePath)
        {
            if (!FFmpegLocator.IsAvailable)
                throw new InvalidOperationException(
                    "تعذّر إيجاد FFmpeg. ضع ffmpeg.exe وffprobe.exe داخل مجلد \"ffmpeg\" بجانب البرنامج، أو أضفهما إلى PATH.");

            var dir = System.IO.Path.GetDirectoryName(FFmpegLocator.FFmpegPath)!;
            FFmpeg.SetExecutablesPath(dir);

            var info = await FFmpeg.GetMediaInfo(filePath);
            var v = info.VideoStreams.FirstOrDefault();
            var hasAudio = info.AudioStreams.Any();

            return new MediaProbeResult
            {
                Width = v?.Width ?? 1280,
                Height = v?.Height ?? 720,
                FrameRate = v?.Framerate > 0 ? v.Framerate : 30,
                Duration = info.Duration,
                HasVideo = v != null,
                HasAudio = hasAudio
            };
        }
    }
}
