using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Meftah.Engine.Playback
{
    /// <summary>
    /// يشغّل ffmpeg كعملية فرعية (Process) ويطلب منه فك ترميز الفيديو وإخراج
    /// إطارات خام بصيغة BGRA (تطابق PixelFormats.Bgra32 في WPF مباشرة —
    /// بدون أي تحويل صيغة إضافي) عبر الأنبوب القياسي (stdout).
    /// هذا يستبدل WPF MediaElement كمصدر فك التشفير والعرض.
    /// </summary>
    public sealed class FFmpegVideoDecoder : IDisposable
    {
        public int Width { get; }
        public int Height { get; }
        public double FrameRate { get; }

        private readonly Process _process;
        private readonly Stream _stdout;
        private readonly int _frameBytes;
        private readonly byte[] _frameBuffer;
        private readonly StringBuilder _stderrLog = new();

        /// نص آخر ما كتبه ffmpeg على stderr — كان يُهمَل بالكامل سابقاً، ما يجعل
        /// أي فشل صامتاً (شاشة سوداء بلا أي تفسير). الآن يُلتقط ليُعرَض للمستخدم
        /// عبر ErrorOccurred عندما لا يُنتَج أي إطار إطلاقاً.
        public string LastErrorOutput => _stderrLog.ToString();

        private FFmpegVideoDecoder(Process process, int width, int height, double frameRate)
        {
            _process = process;
            _stdout = process.StandardOutput.BaseStream;
            Width = width;
            Height = height;
            FrameRate = frameRate;
            _frameBytes = width * height * 4;
            _frameBuffer = new byte[_frameBytes];
        }

        /// <param name="maxWidth">حد أقصى لعرض إطار المعاينة (تصغير الملفات الكبيرة/4K لأداء أفضل في المعاينة فقط)</param>
        public static FFmpegVideoDecoder Start(string filePath, int sourceWidth, int sourceHeight, double sourceFps, TimeSpan startAt, int maxWidth = 1280)
        {
            if (!FFmpegLocator.IsAvailable)
                throw new InvalidOperationException(
                    "تعذّر إيجاد FFmpeg. ضع ffmpeg.exe داخل مجلد \"ffmpeg\" بجانب البرنامج، أو أضفه إلى PATH.");

            int w = Math.Max(2, sourceWidth), h = Math.Max(2, sourceHeight);
            if (w > maxWidth && maxWidth > 0)
            {
                h = (int)Math.Round(h * (maxWidth / (double)w));
                h -= h % 2; // rawvideo يتطلب أبعاداً زوجية
                w = maxWidth;
            }
            else
            {
                w -= w % 2; h -= h % 2;
            }
            double fps = sourceFps > 0 ? sourceFps : 30;

            var ss = startAt.TotalSeconds.ToString(CultureInfo.InvariantCulture);

            var psi = new ProcessStartInfo
            {
                FileName = FFmpegLocator.FFmpegPath!,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            // ArgumentList بدل سطر Arguments نصي واحد — يتفادى أي التباس في اقتباس
            // مسار الملف (خصوصاً لو احتوى مسافات أو أحرفاً خاصة).
            psi.ArgumentList.Add("-ss"); psi.ArgumentList.Add(ss);
            psi.ArgumentList.Add("-i"); psi.ArgumentList.Add(filePath);
            psi.ArgumentList.Add("-f"); psi.ArgumentList.Add("rawvideo");
            psi.ArgumentList.Add("-pix_fmt"); psi.ArgumentList.Add("bgra");
            psi.ArgumentList.Add("-vf"); psi.ArgumentList.Add($"scale={w}:{h}");
            psi.ArgumentList.Add("-an");
            psi.ArgumentList.Add("-loglevel"); psi.ArgumentList.Add("error");
            psi.ArgumentList.Add("pipe:1");

            var process = Process.Start(psi) ?? throw new InvalidOperationException("تعذّر تشغيل ffmpeg (فيديو).");
            var decoder = new FFmpegVideoDecoder(process, w, h, fps);
            decoder.DrainStderr();
            return decoder;
        }

        private void DrainStderr() => Task.Run(() =>
        {
            try
            {
                var buf = new char[512];
                using var reader = new StreamReader(_process.StandardError.BaseStream);
                int n;
                while ((n = reader.Read(buf, 0, buf.Length)) > 0)
                {
                    lock (_stderrLog)
                    {
                        _stderrLog.Append(buf, 0, n);
                        // احتفظ بآخر ~4000 حرف فقط تجنباً لنمو غير محدود
                        if (_stderrLog.Length > 4000) _stderrLog.Remove(0, _stderrLog.Length - 4000);
                    }
                }
            }
            catch { /* العملية أُنهيت */ }
        });

        /// يقرأ الإطار التالي الكامل (BGRA)، أو null إذا انتهى التدفق أو أُغلقت العملية
        public byte[]? ReadNextFrame()
        {
            int readTotal = 0;
            try
            {
                while (readTotal < _frameBytes)
                {
                    int n = _stdout.Read(_frameBuffer, readTotal, _frameBytes - readTotal);
                    if (n <= 0) return null;
                    readTotal += n;
                }
            }
            catch (ObjectDisposedException) { return null; }
            catch (IOException) { return null; }
            return _frameBuffer;
        }

        public void Dispose()
        {
            try { if (!_process.HasExited) _process.Kill(entireProcessTree: true); } catch { /* تجاهل — العملية قد تكون انتهت بالفعل */ }
            _process.Dispose();
        }
    }
}
