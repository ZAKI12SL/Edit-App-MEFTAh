using System;
using System.IO;

namespace Meftah.Engine.Playback
{
    /// <summary>
    /// يحدد مسار ffmpeg وffprobe على جهاز المستخدم. مفتاح لا يوزّع نسخة من
    /// FFmpeg داخله (ترخيص/توزيع الملفات التنفيذية مسؤولية منفصلة) — على
    /// المستخدم تنزيل build ثابت من ffmpeg.org ثم إما:
    ///   1) وضع ffmpeg.exe وffprobe.exe داخل مجلد اسمه "ffmpeg" بجانب ملف
    ///      تشغيل البرنامج (MeftahEditor.exe)، أو
    ///   2) إضافتهما إلى متغير البيئة PATH في النظام.
    /// </summary>
    public static class FFmpegLocator
    {
        private static string? _ffmpegPath;
        private static string? _ffprobePath;
        private static bool _resolved;

        public static string? FFmpegPath { get { Resolve(); return _ffmpegPath; } }
        public static string? FFprobePath { get { Resolve(); return _ffprobePath; } }
        public static bool IsAvailable { get { Resolve(); return _ffmpegPath != null; } }

        private static void Resolve()
        {
            if (_resolved) return;
            _resolved = true;
            _ffmpegPath = Locate("ffmpeg.exe", "ffmpeg");
            _ffprobePath = Locate("ffprobe.exe", "ffprobe");
        }

        /// يعيد محاولة البحث من جديد (مفيد لو المستخدم وضع الملفات بعد تشغيل البرنامج)
        public static void Refresh() => _resolved = false;

        private static string? Locate(string exeNameWindows, string exeNameOther)
        {
            var exeName = OperatingSystem.IsWindows() ? exeNameWindows : exeNameOther;

            var localFfmpegFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ffmpeg", exeName);
            if (File.Exists(localFfmpegFolder)) return localFfmpegFolder;

            var besideExe = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, exeName);
            if (File.Exists(besideExe)) return besideExe;

            var pathVar = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (var dir in pathVar.Split(Path.PathSeparator))
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(dir)) continue;
                    var candidate = Path.Combine(dir, exeName);
                    if (File.Exists(candidate)) return candidate;
                }
                catch { /* مدخل غير صالح في PATH — تجاهله ومتابعة البحث */ }
            }
            return null;
        }
    }
}
