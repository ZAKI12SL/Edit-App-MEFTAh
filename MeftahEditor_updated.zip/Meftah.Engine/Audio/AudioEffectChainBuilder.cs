using System.Collections.Generic;
using Meftah.Core.Models.Audio;
using NAudio.Wave;

namespace Meftah.Engine.Audio
{
    /// <summary>
    /// يحوّل قائمة مؤثرات (معاملات فقط، من Meftah.Core) إلى سلسلة معالجة صوت
    /// حقيقية (ISampleProvider) تُطبَّق بالتتابع. هذا هو الجسر الوحيد بين طبقة
    /// الـCore (بيانات) وطبقة الـEngine (DSP فعلي).
    /// </summary>
    public static class AudioEffectChainBuilder
    {
        public static ISampleProvider Build(ISampleProvider source, IEnumerable<AudioEffectBase> effects)
        {
            ISampleProvider current = source;
            foreach (var fx in effects)
            {
                if (!fx.IsEnabled) continue;
                current = fx switch
                {
                    AmplifyEffect a => new AmplifyProvider(current, a),
                    BalanceEffect b => new BalanceProvider(current, b),
                    ParametricEqEffect eq => new ParametricEqProvider(current, eq),
                    BassEffect bass => new ShelfProvider(current, () => bass.Frequency, () => bass.BoostDb, isLowShelf: true),
                    TrebleEffect treble => new ShelfProvider(current, () => treble.Frequency, () => treble.BoostDb, isLowShelf: false),
                    HighpassEffect hp => new SimpleFilterProvider(current, BiquadFilterType.HighPass, () => hp.CutoffFrequency),
                    LowpassEffect lp => new SimpleFilterProvider(current, BiquadFilterType.LowPass, () => lp.CutoffFrequency),
                    NoiseGateEffect ng => new NoiseGateProvider(current, ng),
                    DynamicsEffect dy => new DynamicsProvider(current, dy),
                    DelayEffect dl => new DelayProvider(current, () => dl.DelayMs, () => dl.Feedback, () => dl.Mix),
                    EchoEffect ec => new DelayProvider(current, () => ec.DelayMs, () => ec.Decay, () => ec.Mix),
                    ReverbEffect rv => new ReverbProvider(current, rv),
                    _ => current // احتياط: مؤثر معرَّف في الـCore لكن لم يُربط بعد بمعالج DSP
                };
            }
            return current;
        }
    }
}
