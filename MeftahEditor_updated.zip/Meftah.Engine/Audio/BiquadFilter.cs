using System;

namespace Meftah.Engine.Audio
{
    public enum BiquadFilterType { LowPass, HighPass, LowShelf, HighShelf, Peaking, Notch }

    /// <summary>
    /// فلتر Biquad قياسي من الدرجة الثانية (معادلات Robert Bristow-Johnson
    /// "Audio EQ Cookbook") — يُستخدم كأساس DSP حقيقي لكل من: Parametric EQ،
    /// Bass، Treble، Highpass، Lowpass. يحتفظ كل نسخة بحالتها الداخلية
    /// (x1,x2,y1,y2) لذا يجب إنشاء نسخة منفصلة لكل قناة صوت (Left/Right).
    /// </summary>
    public sealed class BiquadFilter
    {
        private double _b0, _b1, _b2, _a1, _a2;
        private double _x1, _x2, _y1, _y2;

        public void Configure(BiquadFilterType type, double sampleRate, double frequency, double q, double gainDb)
        {
            if (sampleRate <= 0) sampleRate = 44100;
            frequency = Math.Clamp(frequency, 20, Math.Max(21, sampleRate / 2 - 100));
            q = Math.Max(q, 0.1);
            double a = Math.Pow(10, gainDb / 40.0);
            double w0 = 2 * Math.PI * frequency / sampleRate;
            double cosw0 = Math.Cos(w0);
            double sinw0 = Math.Sin(w0);
            double alpha = sinw0 / (2 * q);
            double b0, b1, b2, a0, a1, a2;

            switch (type)
            {
                case BiquadFilterType.LowPass:
                    b0 = (1 - cosw0) / 2; b1 = 1 - cosw0; b2 = (1 - cosw0) / 2;
                    a0 = 1 + alpha; a1 = -2 * cosw0; a2 = 1 - alpha;
                    break;
                case BiquadFilterType.HighPass:
                    b0 = (1 + cosw0) / 2; b1 = -(1 + cosw0); b2 = (1 + cosw0) / 2;
                    a0 = 1 + alpha; a1 = -2 * cosw0; a2 = 1 - alpha;
                    break;
                case BiquadFilterType.Notch:
                    b0 = 1; b1 = -2 * cosw0; b2 = 1;
                    a0 = 1 + alpha; a1 = -2 * cosw0; a2 = 1 - alpha;
                    break;
                case BiquadFilterType.LowShelf:
                {
                    double sq = 2 * Math.Sqrt(a) * alpha;
                    b0 = a * ((a + 1) - (a - 1) * cosw0 + sq);
                    b1 = 2 * a * ((a - 1) - (a + 1) * cosw0);
                    b2 = a * ((a + 1) - (a - 1) * cosw0 - sq);
                    a0 = (a + 1) + (a - 1) * cosw0 + sq;
                    a1 = -2 * ((a - 1) + (a + 1) * cosw0);
                    a2 = (a + 1) + (a - 1) * cosw0 - sq;
                    break;
                }
                case BiquadFilterType.HighShelf:
                {
                    double sq = 2 * Math.Sqrt(a) * alpha;
                    b0 = a * ((a + 1) + (a - 1) * cosw0 + sq);
                    b1 = -2 * a * ((a - 1) + (a + 1) * cosw0);
                    b2 = a * ((a + 1) + (a - 1) * cosw0 - sq);
                    a0 = (a + 1) - (a - 1) * cosw0 + sq;
                    a1 = 2 * ((a - 1) - (a + 1) * cosw0);
                    a2 = (a + 1) - (a - 1) * cosw0 - sq;
                    break;
                }
                default: // Peaking
                    b0 = 1 + alpha * a; b1 = -2 * cosw0; b2 = 1 - alpha * a;
                    a0 = 1 + alpha / a; a1 = -2 * cosw0; a2 = 1 - alpha / a;
                    break;
            }

            _b0 = b0 / a0; _b1 = b1 / a0; _b2 = b2 / a0; _a1 = a1 / a0; _a2 = a2 / a0;
        }

        public float Process(float input)
        {
            double x0 = input;
            double y0 = _b0 * x0 + _b1 * _x1 + _b2 * _x2 - _a1 * _y1 - _a2 * _y2;
            _x2 = _x1; _x1 = x0;
            _y2 = _y1; _y1 = y0;
            return (float)y0;
        }
    }
}
