using System;
using System.Linq;
using Meftah.Core.Models.Audio;
using NAudio.Wave;

namespace Meftah.Engine.Audio
{
    // كل صنف هنا هو معالج DSP حقيقي يعمل عيّنة بعيّنة (sample-by-sample) على
    // مصدر صوت ISampleProvider (تنسيق float 32-bit، عادة استيريو interleaved).

    internal sealed class AmplifyProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly AmplifyEffect _fx;
        public AmplifyProvider(ISampleProvider source, AmplifyEffect fx) { _source = source; _fx = fx; }
        public WaveFormat WaveFormat => _source.WaveFormat;
        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            float gain = (float)Math.Pow(10, _fx.GainDb / 20.0);
            for (int i = 0; i < read; i++) buffer[offset + i] *= gain;
            return read;
        }
    }

    internal sealed class BalanceProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly BalanceEffect _fx;
        public BalanceProvider(ISampleProvider source, BalanceEffect fx) { _source = source; _fx = fx; }
        public WaveFormat WaveFormat => _source.WaveFormat;
        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            if (WaveFormat.Channels != 2) return read;
            double pan = Math.Clamp(_fx.Pan, -100, 100) / 100.0; // -1..1
            double angle = (pan + 1) * Math.PI / 4;               // 0..PI/2 (Equal-Power Pan)
            float leftGain = (float)Math.Cos(angle);
            float rightGain = (float)Math.Sin(angle);
            for (int i = 0; i + 1 < read; i += 2)
            {
                buffer[offset + i] *= leftGain;
                buffer[offset + i + 1] *= rightGain;
            }
            return read;
        }
    }

    internal sealed class ParametricEqProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly ParametricEqEffect _fx;
        private readonly BiquadFilter[] _low = { new(), new() };
        private readonly BiquadFilter[] _mid = { new(), new() };
        private readonly BiquadFilter[] _high = { new(), new() };
        private double _lastLowFreq = double.NaN, _lastLowGain = double.NaN;
        private double _lastMidFreq = double.NaN, _lastMidGain = double.NaN, _lastMidQ = double.NaN;
        private double _lastHighFreq = double.NaN, _lastHighGain = double.NaN;

        public ParametricEqProvider(ISampleProvider source, ParametricEqEffect fx) { _source = source; _fx = fx; }
        public WaveFormat WaveFormat => _source.WaveFormat;

        private void UpdateCoefficients()
        {
            int sr = WaveFormat.SampleRate;
            if (_fx.LowShelfFreq != _lastLowFreq || _fx.LowShelfGainDb != _lastLowGain)
            {
                foreach (var f in _low) f.Configure(BiquadFilterType.LowShelf, sr, _fx.LowShelfFreq, 0.707, _fx.LowShelfGainDb);
                _lastLowFreq = _fx.LowShelfFreq; _lastLowGain = _fx.LowShelfGainDb;
            }
            if (_fx.MidFreq != _lastMidFreq || _fx.MidGainDb != _lastMidGain || _fx.MidQ != _lastMidQ)
            {
                foreach (var f in _mid) f.Configure(BiquadFilterType.Peaking, sr, _fx.MidFreq, _fx.MidQ, _fx.MidGainDb);
                _lastMidFreq = _fx.MidFreq; _lastMidGain = _fx.MidGainDb; _lastMidQ = _fx.MidQ;
            }
            if (_fx.HighShelfFreq != _lastHighFreq || _fx.HighShelfGainDb != _lastHighGain)
            {
                foreach (var f in _high) f.Configure(BiquadFilterType.HighShelf, sr, _fx.HighShelfFreq, 0.707, _fx.HighShelfGainDb);
                _lastHighFreq = _fx.HighShelfFreq; _lastHighGain = _fx.HighShelfGainDb;
            }
        }

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            UpdateCoefficients();
            int channels = Math.Max(WaveFormat.Channels, 1);
            for (int i = 0; i < read; i++)
            {
                int ch = channels == 2 ? (i % 2) : 0;
                float s = buffer[offset + i];
                s = _low[ch].Process(s);
                s = _mid[ch].Process(s);
                s = _high[ch].Process(s);
                buffer[offset + i] = s;
            }
            return read;
        }
    }

    /// معالج فلتر Shelf عام تُستخدم منه Bass وTreble (Low Shelf / High Shelf)
    internal sealed class ShelfProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly Func<double> _freq;
        private readonly Func<double> _gainDb;
        private readonly bool _isLowShelf;
        private readonly BiquadFilter[] _filters = { new(), new() };
        private double _lastFreq = double.NaN, _lastGain = double.NaN;

        public ShelfProvider(ISampleProvider source, Func<double> freq, Func<double> gainDb, bool isLowShelf)
        { _source = source; _freq = freq; _gainDb = gainDb; _isLowShelf = isLowShelf; }

        public WaveFormat WaveFormat => _source.WaveFormat;

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            double f = _freq(), g = _gainDb();
            if (f != _lastFreq || g != _lastGain)
            {
                foreach (var flt in _filters)
                    flt.Configure(_isLowShelf ? BiquadFilterType.LowShelf : BiquadFilterType.HighShelf, WaveFormat.SampleRate, f, 0.707, g);
                _lastFreq = f; _lastGain = g;
            }
            int channels = Math.Max(WaveFormat.Channels, 1);
            for (int i = 0; i < read; i++)
            {
                int ch = channels == 2 ? (i % 2) : 0;
                buffer[offset + i] = _filters[ch].Process(buffer[offset + i]);
            }
            return read;
        }
    }

    /// معالج Highpass / Lowpass عام
    internal sealed class SimpleFilterProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly BiquadFilterType _type;
        private readonly Func<double> _freq;
        private readonly BiquadFilter[] _filters = { new(), new() };
        private double _lastFreq = double.NaN;

        public SimpleFilterProvider(ISampleProvider source, BiquadFilterType type, Func<double> freq)
        { _source = source; _type = type; _freq = freq; }

        public WaveFormat WaveFormat => _source.WaveFormat;

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            double f = _freq();
            if (f != _lastFreq)
            {
                foreach (var flt in _filters) flt.Configure(_type, WaveFormat.SampleRate, f, 0.707, 0);
                _lastFreq = f;
            }
            int channels = Math.Max(WaveFormat.Channels, 1);
            for (int i = 0; i < read; i++)
            {
                int ch = channels == 2 ? (i % 2) : 0;
                buffer[offset + i] = _filters[ch].Process(buffer[offset + i]);
            }
            return read;
        }
    }

    internal sealed class NoiseGateProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly NoiseGateEffect _fx;
        private float _envelope;
        private float _gain = 1f;

        public NoiseGateProvider(ISampleProvider source, NoiseGateEffect fx) { _source = source; _fx = fx; }
        public WaveFormat WaveFormat => _source.WaveFormat;

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            int sr = Math.Max(WaveFormat.SampleRate, 1);
            float attackCoeff = (float)Math.Exp(-1.0 / (sr * Math.Max(_fx.AttackMs, 0.1) / 1000.0));
            float releaseCoeff = (float)Math.Exp(-1.0 / (sr * Math.Max(_fx.ReleaseMs, 0.1) / 1000.0));
            float thresholdLinear = (float)Math.Pow(10, _fx.ThresholdDb / 20.0);

            for (int i = 0; i < read; i++)
            {
                float s = buffer[offset + i];
                float rectified = Math.Abs(s);
                _envelope = rectified > _envelope
                    ? attackCoeff * _envelope + (1 - attackCoeff) * rectified
                    : releaseCoeff * _envelope + (1 - releaseCoeff) * rectified;
                float targetGain = _envelope >= thresholdLinear ? 1f : 0f;
                _gain += (targetGain - _gain) * 0.01f; // تنعيم لتفادي طقطقة الفتح/الإغلاق المفاجئ
                buffer[offset + i] = s * _gain;
            }
            return read;
        }
    }

    internal sealed class DynamicsProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly DynamicsEffect _fx;
        private float _envelope;

        public DynamicsProvider(ISampleProvider source, DynamicsEffect fx) { _source = source; _fx = fx; }
        public WaveFormat WaveFormat => _source.WaveFormat;

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            if (!_fx.CompressorEnabled && !_fx.LimiterEnabled && !_fx.NoiseGateEnabled) return read;

            int sr = Math.Max(WaveFormat.SampleRate, 1);
            float attackCoeff = (float)Math.Exp(-1.0 / (sr * Math.Max(_fx.AttackMs, 0.1) / 1000.0));
            float releaseCoeff = (float)Math.Exp(-1.0 / (sr * Math.Max(_fx.ReleaseMs, 0.1) / 1000.0));
            float thresholdDb = (float)_fx.ThresholdDb;
            float ratio = (float)Math.Max(_fx.Ratio, 1.0);
            float makeup = (float)Math.Pow(10, _fx.MakeupGainDb / 20.0);
            float gateThresholdLinear = (float)Math.Pow(10, _fx.GateThresholdDb / 20.0);
            float ceilingLinear = (float)Math.Pow(10, _fx.LimiterCeilingDb / 20.0);

            for (int i = 0; i < read; i++)
            {
                float s = buffer[offset + i];
                float rectified = Math.Abs(s);
                _envelope = rectified > _envelope
                    ? attackCoeff * _envelope + (1 - attackCoeff) * rectified
                    : releaseCoeff * _envelope + (1 - releaseCoeff) * rectified;

                float outSample = s;

                if (_fx.CompressorEnabled)
                {
                    float envDb = 20f * (float)Math.Log10(Math.Max(_envelope, 1e-6f));
                    float gainDb = 0;
                    if (envDb > thresholdDb) gainDb = (thresholdDb - envDb) * (1 - 1 / ratio);
                    outSample *= (float)Math.Pow(10, gainDb / 20.0) * makeup;
                }

                if (_fx.NoiseGateEnabled && _envelope < gateThresholdLinear)
                    outSample = 0;

                if (_fx.LimiterEnabled && Math.Abs(outSample) > ceilingLinear)
                    outSample = Math.Sign(outSample) * ceilingLinear;

                buffer[offset + i] = outSample;
            }
            return read;
        }
    }

    /// معالج Delay / Echo — كلاهما نفس الخوارزمية (تأخير + تغذية راجعة) بقيم افتراضية مختلفة
    internal sealed class DelayProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly Func<double> _delayMs;
        private readonly Func<double> _feedbackPercent;
        private readonly Func<double> _mixPercent;
        private float[]? _buffer;
        private int _writePos;

        public DelayProvider(ISampleProvider source, Func<double> delayMs, Func<double> feedbackPercent, Func<double> mixPercent)
        { _source = source; _delayMs = delayMs; _feedbackPercent = feedbackPercent; _mixPercent = mixPercent; }

        public WaveFormat WaveFormat => _source.WaveFormat;

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            int channels = Math.Max(WaveFormat.Channels, 1);
            int delaySamples = Math.Max(channels, (int)(WaveFormat.SampleRate * (_delayMs() / 1000.0)) * channels);

            if (_buffer == null || _buffer.Length != delaySamples)
            {
                _buffer = new float[delaySamples];
                _writePos = 0;
            }

            float feedback = (float)Math.Clamp(_feedbackPercent() / 100.0, 0, 0.95);
            float mix = (float)Math.Clamp(_mixPercent() / 100.0, 0, 1);

            for (int i = 0; i < read; i++)
            {
                float dry = buffer[offset + i];
                float wet = _buffer![_writePos];
                _buffer[_writePos] = dry + wet * feedback;
                _writePos = (_writePos + 1) % _buffer.Length;
                buffer[offset + i] = dry * (1 - mix) + wet * mix;
            }
            return read;
        }
    }

    /// Reverb — Schroeder Reverb مبسّط (4 Comb Filters متوازية + 2 Allpass متسلسلة لكل قناة)
    internal sealed class ReverbProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly ReverbEffect _fx;
        private CombFilter[]? _combsL, _combsR;
        private AllPassFilter[]? _allpassL, _allpassR;
        private int _configuredSr;

        private static readonly int[] CombTunings = { 1557, 1617, 1491, 1422 };
        private static readonly int[] AllpassTunings = { 225, 556 };

        public ReverbProvider(ISampleProvider source, ReverbEffect fx) { _source = source; _fx = fx; }
        public WaveFormat WaveFormat => _source.WaveFormat;

        private void EnsureFilters()
        {
            int sr = Math.Max(WaveFormat.SampleRate, 1);
            if (_combsL != null && _configuredSr == sr) return;
            _configuredSr = sr;
            double scale = sr / 44100.0;
            _combsL = CombTunings.Select(t => new CombFilter((int)(t * scale))).ToArray();
            _combsR = CombTunings.Select(t => new CombFilter((int)(t * scale) + 23)).ToArray(); // إزاحة بسيطة لعرض استيريو
            _allpassL = AllpassTunings.Select(t => new AllPassFilter((int)(t * scale))).ToArray();
            _allpassR = AllpassTunings.Select(t => new AllPassFilter((int)(t * scale) + 17)).ToArray();
        }

        public int Read(float[] buffer, int offset, int count)
        {
            int read = _source.Read(buffer, offset, count);
            EnsureFilters();
            int channels = Math.Max(WaveFormat.Channels, 1);
            float feedback = 0.28f + (float)(_fx.RoomSize / 100.0) * 0.7f;
            float damping = (float)Math.Clamp(_fx.Damping / 100.0, 0, 1);
            float mix = (float)Math.Clamp(_fx.Mix / 100.0, 0, 1);

            for (int i = 0; i + channels - 1 < read; i += channels)
            {
                float inL = buffer[offset + i];
                float inR = channels > 1 ? buffer[offset + i + 1] : inL;

                float wetL = 0, wetR = 0;
                foreach (var c in _combsL!) wetL += c.Process(inL, feedback, damping);
                foreach (var c in _combsR!) wetR += c.Process(inR, feedback, damping);
                foreach (var a in _allpassL!) wetL = a.Process(wetL);
                foreach (var a in _allpassR!) wetR = a.Process(wetR);

                buffer[offset + i] = inL * (1 - mix) + wetL * 0.25f * mix;
                if (channels > 1) buffer[offset + i + 1] = inR * (1 - mix) + wetR * 0.25f * mix;
            }
            return read;
        }

        private sealed class CombFilter
        {
            private readonly float[] _buf; private int _pos; private float _filterStore;
            public CombFilter(int size) { _buf = new float[Math.Max(size, 1)]; }
            public float Process(float input, float feedback, float damping)
            {
                float output = _buf[_pos];
                _filterStore = output * (1 - damping) + _filterStore * damping;
                _buf[_pos] = input + _filterStore * feedback;
                _pos = (_pos + 1) % _buf.Length;
                return output;
            }
        }

        private sealed class AllPassFilter
        {
            private readonly float[] _buf; private int _pos;
            public AllPassFilter(int size) { _buf = new float[Math.Max(size, 1)]; }
            public float Process(float input)
            {
                float bufOut = _buf[_pos];
                float output = -input + bufOut;
                _buf[_pos] = input + bufOut * 0.5f;
                _pos = (_pos + 1) % _buf.Length;
                return output;
            }
        }
    }
}
