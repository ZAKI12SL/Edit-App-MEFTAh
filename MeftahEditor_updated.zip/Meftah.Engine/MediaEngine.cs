using System;
using System.IO;
using System.Threading.Tasks;
using Meftah.Core.Models;
using Meftah.Engine.Playback;
using Xabe.FFmpeg;

namespace Meftah.Engine
{
    public class MediaEngine
    {
        public MediaEngine()
        {
            if (FFmpegLocator.IsAvailable)
                FFmpeg.SetExecutablesPath(Path.GetDirectoryName(FFmpegLocator.FFmpegPath)!);
        }

        public async Task<MediaItem> ProbeAsync(string filePath)
        {
            var item = new MediaItem
            {
                FilePath = filePath,
                MediaType = Path.GetExtension(filePath).ToUpperInvariant()
            };
            try
            {
                var info = await FFmpeg.GetMediaInfo(filePath);
                item.Duration = info.Duration;
            }
            catch { /* FFmpeg غير متوفر أو تعذّر قراءة الملف — يكمل بدون مدة */ }
            return item;
        }
    }
}
