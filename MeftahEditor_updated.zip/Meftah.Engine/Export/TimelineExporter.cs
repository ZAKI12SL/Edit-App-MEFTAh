using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Meftah.Core.Models;
using Meftah.Engine.Playback;

namespace Meftah.Engine.Export
{
    /// <summary>
    /// نظام تصدير احترافي حقيقي للتايم لاين كاملاً عبر FFmpeg — بديل الزر
    /// الوهمي القديم (كان مجرد رسالة "wire up in next milestone").
    ///
    /// يبني رسم مرشّحات (filter_complex) واحد لكل عملية التصدير:
    ///   • الفيديو: كل مسار فيديو (بترتيبه في التايم لاين) يُقصّ عند حدود
    ///     كل مقطع (in/out الحقيقية عبر SourceIn)، يُموضَع زمنياً بمكانه
    ///     الصحيح على المحور، ثم يُركَّب (overlay) فوق قاعدة سوداء بحجم
    ///     المشروع — والمسارات اللاحقة تتراكب فوق السابقة (V2 فوق V1...).
    ///   • الصوت: كل مقطع صوتي غير مكتوم (من مسار صوت مستقل أو مرافق لمقطع
    ///     فيديو) يُقصّ ويُؤخَّر لموضعه ثم يُمزَج (amix) مع تطبيق حجم
    ///     المقطع × حجم المسار، واحترام الكتم (Mute) والعزل (Solo) لكل مسار.
    ///   • تقدّم التصدير الحي يُقرَأ من مخرجات FFmpeg (stderr: "time=...").
    ///
    /// حدود معروفة (بنفس روح ملاحظات AudioEngine الأخرى في المشروع): سلاسل
    /// مؤثرات الصوت (EffectsChain) الخاصة بكل مقطع/مسار غير مطبَّقة هنا بعد
    /// — يُطبَّق الحجم (Volume) فقط؛ إضافة الفلاتر الصوتية الكاملة (EQ,
    /// Reverb...) للتصدير خطوة تالية مخطط لها.
    /// </summary>
    public class TimelineExporter
    {
        public async Task ExportAsync(Timeline timeline, ProjectSettings settings, string outputPath,
            IProgress<double>? progress = null, CancellationToken ct = default)
        {
            if (!FFmpegLocator.IsAvailable || FFmpegLocator.FFmpegPath == null)
                throw new InvalidOperationException(
                    "FFmpeg غير متوفر. ضع ffmpeg.exe وffprobe.exe داخل مجلد \"ffmpeg\" بجانب البرنامج، أو أضفهما إلى PATH.");

            var totalDuration = timeline.TotalDuration();
            if (totalDuration <= TimeSpan.Zero)
                throw new InvalidOperationException("التايم لاين فارغ، لا يوجد ما يُصدَّر.");

            int w = settings.Width > 0 ? settings.Width : 1920;
            int h = settings.Height > 0 ? settings.Height : 1080;
            double fps = settings.FrameRate > 0 ? settings.FrameRate : 30;
            double totalSec = totalDuration.TotalSeconds;

            // 1) اجمع كل ملفات المصدر الفريدة المستخدمة فعلاً في التايم لاين، وافحص
            //    كل واحد عبر ffprobe لمعرفة إن كان يملك فيديو/صوت (لتفادي الإشارة
            //    لتيار غير موجود داخل filter_complex).
            var allClips = timeline.AllClips().Where(c => !string.IsNullOrWhiteSpace(c.Source.FilePath)).ToList();
            var files = allClips.Select(c => c.Source.FilePath).Distinct().ToList();
            if (files.Count == 0)
                throw new InvalidOperationException("لا توجد مقاطع مرتبطة بملفات مصدر صالحة على التايم لاين.");

            var probes = new Dictionary<string, MediaProbeResult>();
            foreach (var f in files)
            {
                ct.ThrowIfCancellationRequested();
                try { probes[f] = await FFprobeHelper.ProbeAsync(f); }
                catch { probes[f] = new MediaProbeResult { HasVideo = true, HasAudio = true }; }
            }

            var inputIndex = new Dictionary<string, int>();
            var argList = new List<string> { "-y" };
            for (int i = 0; i < files.Count; i++)
            {
                inputIndex[files[i]] = i;
                argList.Add("-i");
                argList.Add(files[i]);
            }

            var fc = new StringBuilder();

            // 2) الفيديو: تراكب المسارات فوق قاعدة سوداء بترتيبها في التايم لاين.
            fc.Append($"color=c=black:s={w}x{h}:d={F(totalSec)}:r={F(fps)}[vbase0];");
            int vBase = 0, vClipN = 0;
            var videoTracks = timeline.Tracks.OfType<VideoTrack>().Where(t => !t.IsHidden).ToList();
            foreach (var track in videoTracks)
            {
                foreach (var clip in track.Clips.OrderBy(c => c.Start))
                {
                    if (!probes.TryGetValue(clip.Source.FilePath, out var pr) || !pr.HasVideo) continue;
                    int idx = inputIndex[clip.Source.FilePath];
                    double srcIn = clip.SourceIn.TotalSeconds;
                    double srcOut = srcIn + clip.Duration.TotalSeconds;
                    double start = clip.Start.TotalSeconds;
                    double end = clip.End.TotalSeconds;
                    string label = $"vclip{vClipN++}";
                    fc.Append(
                        $"[{idx}:v]trim=start={F(srcIn)}:end={F(srcOut)},setpts=PTS-STARTPTS+{F(start)}/TB," +
                        $"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1[{label}];");
                    int nextBase = vBase + 1;
                    fc.Append($"[vbase{vBase}][{label}]overlay=x=0:y=0:eof_action=pass:enable='between(t,{F(start)},{F(end)})'[vbase{nextBase}];");
                    vBase = nextBase;
                }
            }
            fc.Append($"[vbase{vBase}]format=yuv420p[outv];");

            // 3) الصوت: مزج كل المقاطع الصوتية غير المكتومة، مع احترام Mute/Solo لكل مسار.
            bool anySolo = timeline.Tracks.Any(t => t.IsSolo);
            var aLabels = new List<string>();
            int aClipN = 0;
            foreach (var track in timeline.Tracks)
            {
                bool trackAudible = anySolo ? track.IsSolo : !track.IsMuted;
                if (!trackAudible) continue;
                foreach (var clip in track.Clips)
                {
                    if (clip.IsMuted) continue;
                    if (!probes.TryGetValue(clip.Source.FilePath, out var pr) || !pr.HasAudio) continue;
                    int idx = inputIndex[clip.Source.FilePath];
                    double srcIn = clip.SourceIn.TotalSeconds;
                    double srcOut = srcIn + clip.Duration.TotalSeconds;
                    double startMs = Math.Max(0, clip.Start.TotalMilliseconds);
                    double vol = Math.Max(0, clip.Volume * track.Volume);
                    string label = $"aclip{aClipN++}";
                    fc.Append(
                        $"[{idx}:a]atrim=start={F(srcIn)}:end={F(srcOut)},asetpts=PTS-STARTPTS," +
                        $"adelay={F0(startMs)}|{F0(startMs)},volume={F(vol)}[{label}];");
                    aLabels.Add(label);
                }
            }

            if (aLabels.Count == 0)
            {
                fc.Append($"anullsrc=channel_layout=stereo:sample_rate=48000,atrim=0:{F(totalSec)}[outa];");
            }
            else
            {
                foreach (var l in aLabels) fc.Append($"[{l}]");
                fc.Append($"amix=inputs={aLabels.Count}:duration=longest:normalize=0,atrim=0:{F(totalSec)},asetpts=PTS-STARTPTS[outa];");
            }

            var filterGraph = fc.ToString().TrimEnd(';');

            var outDir = Path.GetDirectoryName(outputPath);
            if (!string.IsNullOrEmpty(outDir)) Directory.CreateDirectory(outDir);

            argList.Add("-filter_complex");
            argList.Add(filterGraph);
            argList.Add("-map"); argList.Add("[outv]");
            argList.Add("-map"); argList.Add("[outa]");
            argList.Add("-r"); argList.Add(F(fps));
            argList.Add("-c:v"); argList.Add("libx264");
            argList.Add("-pix_fmt"); argList.Add("yuv420p");
            argList.Add("-crf"); argList.Add("20");
            argList.Add("-preset"); argList.Add("veryfast");
            argList.Add("-c:a"); argList.Add("aac");
            argList.Add("-b:a"); argList.Add("192k");
            argList.Add("-shortest");
            argList.Add(outputPath);

            await RunFFmpegAsync(argList, totalSec, progress, ct);
        }

        private static string F(double seconds) => seconds.ToString("0.###", CultureInfo.InvariantCulture);
        private static string F0(double v) => v.ToString("0", CultureInfo.InvariantCulture);

        private static async Task RunFFmpegAsync(List<string> args, double totalSeconds, IProgress<double>? progress, CancellationToken ct)
        {
            var psi = new ProcessStartInfo
            {
                FileName = FFmpegLocator.FFmpegPath!,
                RedirectStandardError = true,
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            // استخدام ArgumentList بدل سطر Arguments نصي واحد يتفادى كل مشاكل
            // اقتباس المسارات وعلامات الاقتباس داخل filter_complex نفسه.
            foreach (var a in args) psi.ArgumentList.Add(a);

            using var proc = new Process { StartInfo = psi, EnableRaisingEvents = true };
            var stderr = new StringBuilder();

            proc.ErrorDataReceived += (_, e) =>
            {
                if (e.Data == null) return;
                stderr.AppendLine(e.Data);
                var t = ParseTime(e.Data);
                if (t.HasValue && totalSeconds > 0)
                    progress?.Report(Math.Clamp(t.Value.TotalSeconds / totalSeconds, 0, 1));
            };

            proc.Start();
            proc.BeginErrorReadLine();

            using (ct.Register(() => { try { if (!proc.HasExited) proc.Kill(true); } catch { } }))
            {
                await proc.WaitForExitAsync(ct);
            }

            if (proc.ExitCode != 0)
                throw new InvalidOperationException("فشل FFmpeg أثناء التصدير:\n" + LastLines(stderr.ToString(), 15));

            progress?.Report(1);
        }

        private static TimeSpan? ParseTime(string line)
        {
            var idx = line.IndexOf("time=", StringComparison.Ordinal);
            if (idx < 0) return null;
            var start = idx + 5;
            var end = line.IndexOf(' ', start);
            if (end < 0) end = line.Length;
            var raw = line.Substring(start, end - start).Trim();
            return TimeSpan.TryParse(raw, CultureInfo.InvariantCulture, out var t) ? t : null;
        }

        private static string LastLines(string text, int n)
        {
            var lines = text.Split('\n', StringSplitOptions.RemoveEmptyEntries);
            return string.Join('\n', lines.Skip(Math.Max(0, lines.Length - n)));
        }
    }
}
