using System.Windows;
using Meftah.Core.Services;
namespace Meftah.UI
{
    public partial class App : Application
    {
        public static ProjectService ProjectService { get; } = new();
        public static RecentProjectsService RecentProjects { get; } = new();

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            var dashboard = new Views.DashboardWindow();
            dashboard.Show();
        }
    }
}