using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Meftah.Core.Models;
using Meftah.Engine.Playback;
using Meftah.UI.ViewModels;
namespace Meftah.UI.Views
{
    public partial class EditorWindow : Window
    {
        private Point _dragStart;
        private readonly MediaPlaybackEngine _playback = new();
        private WriteableBitmap? _bitmap;

        public EditorWindow()
        {
            InitializeComponent();
            var vm = new EditorViewModel();
            DataContext = vm;
            vm.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(EditorViewModel.PlayheadPosition))
                    TimecodeBlock.Text = FormatTC(vm.PlayheadPosition);
                if (e.PropertyName == nameof(EditorViewModel.IsMediaLibraryVisible)) ApplyMediaLibraryVisibility(vm.IsMediaLibraryVisible);
                if (e.PropertyName == nameof(EditorViewModel.IsEffectsPanelVisible)) ApplyEffectsPanelVisibility(vm.IsEffectsPanelVisible);
                if (e.PropertyName == nameof(EditorViewModel.IsTimelineVisible)) ApplyTimelineVisibility(vm.IsTimelineVisible);
            };
            // يضبط الحالة الأولية (كلها ظاهرة افتراضياً) بنفس مسار الشيفرة الذي
            // يستخدمه التبديل لاحقاً من قائمة Window، حتى لا يوجد مساران مختلفان.
            ApplyMediaLibraryVisibility(vm.IsMediaLibraryVisible);
            ApplyEffectsPanelVisibility(vm.IsEffectsPanelVisible);
            ApplyTimelineVisibility(vm.IsTimelineVisible);

            if (!FFmpegLocator.IsAvailable)
            {
                PreviewHint.Text = "FFmpeg not found. Place ffmpeg.exe / ffprobe.exe in an \"ffmpeg\" folder next to the app, or add them to PATH.";
                vm.StatusMessage = "FFmpeg not found — preview and export will not work until it is installed.";
            }

            // يُطلَق من خيط الفيديو الداخلي في MediaPlaybackEngine — Dispatcher.Invoke (متزامن) عمداً،
            // لأن نفس المخزن المؤقت (buffer) يُعاد استخدامه للإطار التالي فور عودة هذا المستدعى.
            _playback.FrameReady += (bgra, w, h) =>
                Dispatcher.Invoke(() => RenderFrame(bgra, w, h));
            _playback.PositionChanged += t =>
                Dispatcher.BeginInvoke(() =>
                {
                    TimecodeBlock.Text = FormatTC(t);
                    // يحرّك خط المؤشر في التايم لاين ليطابق نفس اللقطة المعروضة فعلياً
                    if (DataContext is EditorViewModel v) v.SyncPlayheadFromPlayback(t);
                });
            _playback.PlaybackEnded += () =>
                Dispatcher.BeginInvoke(() => { });
            _playback.ErrorOccurred += msg =>
                Dispatcher.BeginInvoke(() =>
                {
                    PreviewHint.Visibility = Visibility.Visible;
                    PreviewHint.Text = "FFmpeg error:\n" + msg;
                    if (DataContext is EditorViewModel v) v.StatusMessage = "FFmpeg: " + msg;
                });
        }

        // ─── Window menu: show/hide panels ─────────────────────────────
        // كل لوحة رئيسية (Media Library / Effect Controls-Audio Mixer / Timeline)
        // تُطوى فعلياً (عمود/صف الشبكة يصبح صفراً) بدل مجرد Visibility=Collapsed
        // على المحتوى — وإلا تبقى مساحة فارغة محجوزة في التخطيط. آخر عرض/ارتفاع
        // معروف يُحفَظ قبل الطي ليُستعاد بنفس القياس عند إعادة الإظهار.
        private double _mediaBinWidth = 260;
        private double _rightPanelWidth = 220;
        private double _timelineHeight = 240;

        private void ApplyMediaLibraryVisibility(bool visible)
        {
            if (visible)
            {
                MediaBinColumn.Width = new GridLength(_mediaBinWidth);
                MediaBinSplitterColumn.Width = new GridLength(4);
                MediaBinPanel.Visibility = Visibility.Visible;
                MediaBinSplitter.Visibility = Visibility.Visible;
            }
            else
            {
                if (MediaBinColumn.Width.Value > 0) _mediaBinWidth = MediaBinColumn.Width.Value;
                MediaBinColumn.Width = new GridLength(0);
                MediaBinSplitterColumn.Width = new GridLength(0);
                MediaBinPanel.Visibility = Visibility.Collapsed;
                MediaBinSplitter.Visibility = Visibility.Collapsed;
            }
        }

        private void ApplyEffectsPanelVisibility(bool visible)
        {
            if (visible)
            {
                RightPanelColumn.Width = new GridLength(_rightPanelWidth);
                RightPanelSplitterColumn.Width = new GridLength(4);
                RightPanelBorder.Visibility = Visibility.Visible;
                RightPanelSplitter.Visibility = Visibility.Visible;
            }
            else
            {
                if (RightPanelColumn.Width.Value > 0) _rightPanelWidth = RightPanelColumn.Width.Value;
                RightPanelColumn.Width = new GridLength(0);
                RightPanelSplitterColumn.Width = new GridLength(0);
                RightPanelBorder.Visibility = Visibility.Collapsed;
                RightPanelSplitter.Visibility = Visibility.Collapsed;
            }
        }

        private void ApplyTimelineVisibility(bool visible)
        {
            if (visible)
            {
                TimelineRow.Height = new GridLength(_timelineHeight);
                TimelineSplitterRow.Height = new GridLength(4);
                TL.Visibility = Visibility.Visible;
                TimelineSplitter.Visibility = Visibility.Visible;
            }
            else
            {
                if (TimelineRow.Height.Value > 0) _timelineHeight = TimelineRow.Height.Value;
                TimelineRow.Height = new GridLength(0);
                TimelineSplitterRow.Height = new GridLength(0);
                TL.Visibility = Visibility.Collapsed;
                TimelineSplitter.Visibility = Visibility.Collapsed;
            }
        }

        private static string FormatTC(TimeSpan t) =>
            $"{(int)t.TotalHours:00}:{t.Minutes:00}:{t.Seconds:00}:{(int)(t.Milliseconds / (1000.0 / 30)):00}";

        private void RenderFrame(byte[] bgra, int width, int height)
        {
            if (_bitmap == null || _bitmap.PixelWidth != width || _bitmap.PixelHeight != height)
                _bitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
            _bitmap.WritePixels(new Int32Rect(0, 0, width, height), bgra, width * 4, 0);
            PreviewImage.Source = _bitmap;
        }

        public async void LoadPreview(MediaItem item)
        {
            PreviewHint.Visibility = Visibility.Collapsed;
            try
            {
                _loadedMediaPath = item.FilePath;
                await _playback.LoadAsync(item);
            }
            catch (Exception ex)
            {
                _loadedMediaPath = null;
                PreviewHint.Visibility = Visibility.Visible;
                PreviewHint.Text = ex.Message;
                if (DataContext is EditorViewModel v) v.StatusMessage = "Preview error: " + ex.Message;
            }
        }

        private string? _loadedMediaPath;

        /// <summary>
        /// يُستدعى من EditorViewModel عند تحرّك مؤشر التشغيل (Playhead) في
        /// التايم لاين — يربط مربع المعاينة (Program Monitor) بما هو موجود
        /// فعلياً تحت المؤشر بدل بقائه فارغاً/غير مرتبط بالتايم لاين كما كان.
        /// </summary>
        public async void PreviewAt(MediaItem item, TimeSpan offsetInSource)
        {
            try
            {
                if (_loadedMediaPath != item.FilePath)
                {
                    PreviewHint.Visibility = Visibility.Collapsed;
                    await _playback.LoadAsync(item);
                    _loadedMediaPath = item.FilePath;
                }
                _playback.Seek(offsetInSource);
            }
            catch (Exception ex)
            {
                _loadedMediaPath = null;
                PreviewHint.Visibility = Visibility.Visible;
                PreviewHint.Text = ex.Message;
                if (DataContext is EditorViewModel v) v.StatusMessage = "Preview error: " + ex.Message;
            }
        }

        /// يُستدعى عندما لا يوجد أي مقطع تحت المؤشر — يعيد إظهار التلميح بدل شاشة سوداء صامتة
        public void ClearPreview()
        {
            if (_loadedMediaPath == null) return;
            _loadedMediaPath = null;
            _playback.Stop();
            PreviewHint.Visibility = Visibility.Visible;
            PreviewHint.Text = "Program Monitor — no clip under the playhead";
        }

        public bool IsPreviewPlaying => _playback.IsPlaying;
        public void PlayPreview() => _playback.Play();
        public void PausePreview() => _playback.Pause();
        public void StopPreview() => _playback.Stop();
        public void SeekPreview(TimeSpan t) => _playback.Seek(t);

        private void Exit_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();

        private void MediaBin_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DataContext is EditorViewModel vm && vm.SelectedMedia != null)
            {
                LoadPreview(vm.SelectedMedia);
                vm.AddSelectedToTimelineCommand.Execute(null);
            }
        }

        private void MediaBin_PreviewMouseDown(object sender, MouseButtonEventArgs e)
            => _dragStart = e.GetPosition(null);

        private void MediaBin_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed) return;
            var pos = e.GetPosition(null);
            if (Math.Abs(pos.X - _dragStart.X) < SystemParameters.MinimumHorizontalDragDistance &&
                Math.Abs(pos.Y - _dragStart.Y) < SystemParameters.MinimumVerticalDragDistance) return;
            if (MediaBinList.SelectedItem is MediaItem item)
                DragDrop.DoDragDrop(MediaBinList, item, DragDropEffects.Copy);
        }

        // ─── Media Library: right-click → New Text / Shape / Path / Adjustment Layer / Color Matte ───
        private void MediaBinList_RightClick(object sender, MouseButtonEventArgs e)
        {
            if (DataContext is not EditorViewModel vm) return;
            var menu = new ContextMenu();
            var newItem = new MenuItem { Header = "New" };
            newItem.Items.Add(MediaMenuItem("New Text", vm.NewTextItemCommand));
            newItem.Items.Add(MediaMenuItem("New Shape", vm.NewShapeItemCommand));
            newItem.Items.Add(MediaMenuItem("New Path", vm.NewPathItemCommand));
            newItem.Items.Add(MediaMenuItem("New Adjustment Layer", vm.NewAdjustmentLayerItemCommand));
            newItem.Items.Add(MediaMenuItem("New Color Matte", vm.NewColorMatteItemCommand));
            menu.Items.Add(newItem);
            menu.PlacementTarget = MediaBinList;
            menu.IsOpen = true;
            e.Handled = true;
        }

        private static MenuItem MediaMenuItem(string header, System.Windows.Input.ICommand command)
        {
            var mi = new MenuItem { Header = header, Command = command };
            return mi;
        }

        // ---- Effect Controls: Add Audio Effect ----
        private void AddEffectButton_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is not EditorViewModel vm || vm.TimelineVM.SelectedClip == null) return;
            var menu = new ContextMenu();
            foreach (var group in EditorViewModel.AvailableAudioEffects.GroupBy(x => x.Category))
            {
                var header = new MenuItem { Header = group.Key, IsEnabled = false, FontWeight = FontWeights.Bold };
                menu.Items.Add(header);
                foreach (var entry in group)
                {
                    var factory = entry.Create;
                    var mi = new MenuItem { Header = "   " + entry.Name };
                    mi.Click += (_, _) => vm.AddEffectToSelectedClip(factory);
                    menu.Items.Add(mi);
                }
            }
            menu.PlacementTarget = (Button)sender;
            menu.IsOpen = true;
        }

        protected override void OnClosed(EventArgs e)
        {
            _playback.Dispose();
            base.OnClosed(e);
        }
    }
}