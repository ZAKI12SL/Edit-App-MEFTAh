using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
namespace Meftah.UI.Views
{
    public partial class DashboardWindow : Window
    {
        public DashboardWindow()
        {
            InitializeComponent();
            LoadRecent();
        }

        private void LoadRecent()
        {
            var list = App.RecentProjects.Load();
            var items = list
                .Where(File.Exists)
                .Select(p => new RecentItem
                {
                    Name = Path.GetFileNameWithoutExtension(p),
                    Path = p,
                    Date = File.GetLastWriteTime(p).ToString("MMM dd, yyyy")
                }).ToList();

            RecentList.ItemsSource = items;
            EmptyHint.Visibility = items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void NewProject_Click(object sender, RoutedEventArgs e)
        {
            App.ProjectService.NewProject();
            OpenEditor();
        }

        private void OpenProject_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Title = "Open Meftah Project",
                Filter = "Meftah Project (*.meftah)|*.meftah|All Files|*.*"
            };
            if (dlg.ShowDialog() != true) return;
            _ = App.ProjectService.LoadAsync(dlg.FileName);
            App.RecentProjects.Add(dlg.FileName);
            OpenEditor();
        }

        private void RecentList_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (RecentList.SelectedItem is not RecentItem item) return;
            _ = App.ProjectService.LoadAsync(item.Path);
            App.RecentProjects.Add(item.Path);
            OpenEditor();
        }

        private void OpenEditor()
        {
            var editor = new EditorWindow();
            // مهم: WPF لا يحدّث Application.MainWindow تلقائياً عند إغلاق النافذة
            // الرئيسية الحالية (Dashboard) — يجب تعيينها يدوياً هنا، وإلا فإن
            // أزرار Play/Pause و Stop داخل EditorViewModel (التي تبحث عن
            // Application.Current.MainWindow as EditorWindow) لن تعمل أبداً.
            Application.Current.MainWindow = editor;
            editor.Show();
            Close();
        }
    }

    public class RecentItem
    {
        public string Name { get; set; } = string.Empty;
        public string Path { get; set; } = string.Empty;
        public string Date { get; set; } = string.Empty;
    }
}