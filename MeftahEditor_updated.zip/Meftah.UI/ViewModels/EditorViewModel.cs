using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Meftah.Core.Commands;
using Meftah.Core.Models;
using Meftah.Core.Models.Audio;
using Meftah.Core.Services;
using Meftah.Engine;
using Meftah.UI.Views;
using Microsoft.Win32;

namespace Meftah.UI.ViewModels
{
    public partial class EditorViewModel : ObservableObject
    {
        private readonly ProjectService _ps = App.ProjectService;
        private readonly MediaEngine _mediaEngine = new();
        private readonly AudioEngine _audioEngine = new();
        private readonly System.Collections.Generic.List<Clip> _clipboard = new();

        [ObservableProperty] private string _statusMessage = "Ready.";
        [ObservableProperty] private MediaItem? _selectedMedia;
        [ObservableProperty] private TimeSpan _playheadPosition;

        // ---- نظام النوافذ (قائمة Window) ----
        // كل خاصية تتحكم بظهور/إخفاء لوحة رئيسية واحدة في نافذة المحرر.
        // EditorWindow.xaml.cs يراقب هذه الخصائص ويطوي/يوسّع اللوحة المطابقة
        // فعلياً (عمود أو صف الشبكة بالإضافة إلى الفاصل المجاور لها) بدل
        // مجرد إخفائها بصرياً وترك مساحة فارغة.
        [ObservableProperty] private bool _isMediaLibraryVisible = true;
        [ObservableProperty] private bool _isEffectsPanelVisible = true;
        [ObservableProperty] private bool _isTimelineVisible = true;

        [RelayCommand]
        private void ResetLayout()
        {
            IsMediaLibraryVisible = true;
            IsEffectsPanelVisible = true;
            IsTimelineVisible = true;
        }

        // ---- Audio Track Mixer ----
        [ObservableProperty] private float _meterLeft;
        [ObservableProperty] private float _meterRight;
        [ObservableProperty] private bool _isAuditioningAudio;

        public ObservableCollection<MediaItem> MediaBin => _ps.MediaBin;
        public TimelineViewModel TimelineVM { get; }

        /// كل مسارات الصوت في المشروع — تُستخدم لعرض شرائط القنوات في Audio Track Mixer
        public System.Collections.Generic.IEnumerable<AudioTrack> AudioTracks => _ps.Timeline.Tracks.OfType<AudioTrack>();

        /// أنواع مؤثرات الصوت المتاحة للإضافة (Effect Controls → Add Effect)
        public static readonly (string Category, string Name, Func<AudioEffectBase> Create)[] AvailableAudioEffects =
        {
            ("Amplitude and Compression", "Amplify",       () => new AmplifyEffect()),
            ("Amplitude and Compression", "Dynamics",       () => new DynamicsEffect()),
            ("Filter & EQ",               "Parametric EQ",  () => new ParametricEqEffect()),
            ("Filter & EQ",               "Bass",           () => new BassEffect()),
            ("Filter & EQ",               "Treble",         () => new TrebleEffect()),
            ("Filter & EQ",               "Highpass",       () => new HighpassEffect()),
            ("Filter & EQ",               "Lowpass",        () => new LowpassEffect()),
            ("Noise Reduction",           "Noise Gate",     () => new NoiseGateEffect()),
            ("Delay & Echo",              "Delay",          () => new DelayEffect()),
            ("Delay & Echo",              "Echo",           () => new EchoEffect()),
            ("Reverb",                    "Reverb",         () => new ReverbEffect()),
            ("Stereo Imaging",            "Balance",        () => new BalanceEffect()),
        };

        // المقطع المعروض حالياً في مربع المعاينة (Program Monitor) — يُستخدم
        // لتحويل زمن التشغيل الفعلي (داخل ملف المصدر) عائداً إلى زمن التايم
        // لاين أثناء التشغيل، حتى يتحرك خط المؤشر مطابقاً لنفس اللقطة.
        private Clip? _previewingClip;

        // يُرفَع أثناء مزامنة المؤشر من التشغيل الفعلي، لمنع تلك المزامنة من
        // إعادة استدعاء UpdatePreviewForPlayhead (وبالتالي Seek جديد على كل
        // إطار) — الفيديو نفسه هو من يقود العرض حينها، لا حاجة لإعادة تحميله.
        private bool _syncingPlayheadFromPlayback;

        public EditorViewModel()
        {
            TimelineVM = new TimelineViewModel(_ps.Timeline, _ps.CommandStack);
            TimelineVM.PlayheadChanged += t =>
            {
                PlayheadPosition = t;
                if (!_syncingPlayheadFromPlayback) UpdatePreviewForPlayhead(t);
            };
            _audioEngine.LevelsChanged += (l, r) =>
                Application.Current.Dispatcher.Invoke(() => { MeterLeft = l; MeterRight = r; });
            // إعادة تقييم AudioTracks كلما أُضيف/حُذف مسار حتى يتحدّث Audio Track Mixer فوراً
            _ps.Timeline.Tracks.CollectionChanged += (_, _) => OnPropertyChanged(nameof(AudioTracks));
        }

        /// يربط مؤشر التشغيل في التايم لاين بمربع المعاينة (Program Monitor):
        /// يبحث عن أعلى مسار فيديو ظاهر يحوي مقطعاً تحت زمن المؤشر الحالي،
        /// ويطلب من نافذة المحرر عرض ذلك الإطار بالضبط. بدون هذا الربط يبقى
        /// مربع المعاينة معزولاً تماماً عن التايم لاين (كما كانت المشكلة).
        private void UpdatePreviewForPlayhead(TimeSpan t)
        {
            if (Application.Current.MainWindow is not EditorWindow win) return;

            var track = _ps.Timeline.Tracks.OfType<VideoTrack>()
                .Where(tr => !tr.IsHidden)
                .Reverse() // المسار الأعلى في القائمة يتراكب فوق ما تحته
                .FirstOrDefault(tr => tr.Clips.Any(c => t >= c.Start && t < c.End));
            var clip = track?.Clips.FirstOrDefault(c => t >= c.Start && t < c.End);
            _previewingClip = clip;

            if (clip == null) { win.ClearPreview(); return; }

            var offset = clip.SourceIn + (t - clip.Start);
            win.PreviewAt(clip.Source, offset);
        }

        /// يُستدعى من نافذة المحرر مع كل إطار يُشغَّل فعلياً في محرك المعاينة
        /// (MediaPlaybackEngine.PositionChanged) — يحوّل زمن التشغيل داخل ملف
        /// المصدر إلى زمن التايم لاين المطابق، ويحرّك خط المؤشر ليتبعه لحظياً
        /// أثناء التشغيل (بدل بقائه ثابتاً في مكانه كما كانت المشكلة).
        public void SyncPlayheadFromPlayback(TimeSpan sourcePosition)
        {
            if (_previewingClip == null) return;
            var t = _previewingClip.Start + (sourcePosition - _previewingClip.SourceIn);
            if (t < TimeSpan.Zero) t = TimeSpan.Zero;
            _syncingPlayheadFromPlayback = true;
            TimelineVM.PlayheadPosition = t;
            _syncingPlayheadFromPlayback = false;
        }

        // ---- Audio Effects (Effect Controls panel) — تُستدعى من قائمة Add Effect في الواجهة ----
        public void AddEffectToSelectedClip(Func<AudioEffectBase> factory)
        {
            var clip = TimelineVM.SelectedClip;
            if (clip == null) return;
            var fx = factory();
            CommandStack_Execute("Add audio effect", () => clip.EffectsChain.Add(fx), () => clip.EffectsChain.Remove(fx));
        }

        [RelayCommand]
        private void RemoveAudioEffect(AudioEffectBase? fx)
        {
            var clip = TimelineVM.SelectedClip;
            if (clip == null || fx == null) return;
            CommandStack_Execute("Remove audio effect", () => clip.EffectsChain.Remove(fx), () => clip.EffectsChain.Add(fx));
        }

        private void CommandStack_Execute(string name, Action doIt, Action undoIt) =>
            _ps.CommandStack.Execute(new DelegateCommand(name, doIt, undoIt));

        // ---- Audition (تشغيل مقطع صوت منفرد مع سلسلة مؤثراته الكاملة) ----
        [RelayCommand]
        private void AuditionSelectedClip()
        {
            var clip = TimelineVM.SelectedClip;
            if (clip == null || string.IsNullOrEmpty(clip.Source.FilePath) || !clip.Source.IsAudio)
            {
                StatusMessage = "Select an audio clip to audition.";
                return;
            }
            if (IsAuditioningAudio && _audioEngine.IsPlaying) { _audioEngine.Pause(); IsAuditioningAudio = false; return; }
            var track = TimelineVM.TrackOf(clip);
            _audioEngine.LoadForAudition(clip.Source.FilePath, clip, track);
            _audioEngine.Play();
            IsAuditioningAudio = true;
            StatusMessage = $"Auditioning: {clip.Name}";
        }

        // ---- Import ----
        [RelayCommand]
        private async Task ImportMediaAsync()
        {
            string? fileName = null;

            Application.Current.Dispatcher.Invoke(() =>
            {
                var dlg = new OpenFileDialog
                {
                    Title = "Import Media",
                    Filter = "Media Files|*.mp4;*.mov;*.avi;*.mkv;*.mp3;*.wav;*.aac|All Files|*.*"
                };
                if (dlg.ShowDialog() == true)
                    fileName = dlg.FileName;
            });

            if (string.IsNullOrEmpty(fileName)) return;

            var item = await _mediaEngine.ProbeAsync(fileName);
            _ps.AddMedia(item);
            StatusMessage = $"Imported: {item.FileName}";
        }

        [RelayCommand]
        public void AddSelectedToTimeline()
        {
            if (SelectedMedia == null) return;
            var track = SelectedMedia.IsAudio
                ? (Track?)_ps.Timeline.Tracks.OfType<AudioTrack>().FirstOrDefault()
                : _ps.Timeline.Tracks.OfType<VideoTrack>().FirstOrDefault();
            if (track == null) { StatusMessage = "No matching track."; return; }
            TimelineVM.AddMediaToTrack(SelectedMedia, track);
            StatusMessage = $"Added {SelectedMedia.FileName} to {track.Name}";
        }

        // ---- Media Library: New Item (right-click) ----
        // تُنشئ عنصر Media Library "مُولَّداً" (بدون ملف حقيقي على القرص) — يظهر
        // فوراً في المكتبة ويمكن سحبه للتايم لاين أو إضافته بنفس طريقة أي
        // عنصر وسائط عادي (InsertAt تتعامل معه بنفس المسار البرمجي).
        [RelayCommand] private void NewTextItem() => AddSyntheticMedia("Text", "#F1C40F");
        [RelayCommand] private void NewShapeItem() => AddSyntheticMedia("Shape", "#8E44AD");
        [RelayCommand] private void NewPathItem() => AddSyntheticMedia("Path", "#16A085");
        [RelayCommand] private void NewAdjustmentLayerItem() => AddSyntheticMedia("Adjustment Layer", "#7F8C8D");
        [RelayCommand] private void NewColorMatteItem() => AddSyntheticMedia("Color Matte", "#E74C3C");

        private void AddSyntheticMedia(string kind, string colorHex)
        {
            int n = MediaBin.Count(m => m.SyntheticKind == kind) + 1;
            var name = $"{kind} {n:00}";
            var item = new MediaItem
            {
                FilePath = name,
                MediaType = kind.ToUpperInvariant().Replace(' ', '_'),
                Duration = TimeSpan.FromSeconds(5),
                IsSynthetic = true,
                SyntheticKind = kind,
                ColorHex = colorHex
            };
            _ps.AddMedia(item);
            SelectedMedia = item;
            StatusMessage = $"Created \"{name}\" — drag it to the timeline to use it.";
        }

        // ---- Transport ----
        [RelayCommand]
        private void PlayPause()
        {
            if (Application.Current.MainWindow is EditorWindow win)
            {
                if (win.IsPreviewPlaying) win.PausePreview();
                else win.PlayPreview();
            }
        }

        [RelayCommand]
        private void Stop()
        {
            if (Application.Current.MainWindow is EditorWindow win) win.StopPreview();
            if (IsAuditioningAudio) { _audioEngine.Stop(); IsAuditioningAudio = false; MeterLeft = 0; MeterRight = 0; }
            PlayheadPosition = TimeSpan.Zero;
        }

        [RelayCommand]
        private void GoToStart() { PlayheadPosition = TimeSpan.Zero; TimelineVM.PlayheadPosition = TimeSpan.Zero; }

        /// خطوة التقديم/التأخير السريع لأزرار ⏪/⏩ أسفل شاشة المعاينة.
        private static readonly TimeSpan SeekStep = TimeSpan.FromSeconds(5);

        [RelayCommand]
        private void SeekBackward()
        {
            var t = TimelineVM.PlayheadPosition - SeekStep;
            TimelineVM.PlayheadPosition = t < TimeSpan.Zero ? TimeSpan.Zero : t;
        }

        [RelayCommand]
        private void SeekForward() => TimelineVM.PlayheadPosition += SeekStep;

        // ---- Edit ----
        [RelayCommand] private void Undo() => _ps.CommandStack.Undo();
        [RelayCommand] private void Redo() => _ps.CommandStack.Redo();
        [RelayCommand] private void Copy() => TimelineVM.Copy();
        [RelayCommand] private void Paste() => TimelineVM.PasteAtPlayhead();
        [RelayCommand] private void Duplicate() => TimelineVM.Duplicate();
        [RelayCommand] private void Delete() => TimelineVM.Delete(ripple: false);
        [RelayCommand] private void RippleDelete() => TimelineVM.Delete(ripple: true);
        [RelayCommand] private void AddMarker() => TimelineVM.AddMarkerAt(PlayheadPosition);
        [RelayCommand]
        private void AddVideoTrack()
        {
            var t = new VideoTrack { Name = $"V{_ps.Timeline.Tracks.OfType<VideoTrack>().Count() + 1}" };
            _ps.CommandStack.Execute(new DelegateCommand("Add video track",
                () => _ps.Timeline.AddTrack(t), () => _ps.Timeline.RemoveTrack(t)));
        }
        [RelayCommand]
        private void AddAudioTrack()
        {
            var t = new AudioTrack { Name = $"A{_ps.Timeline.Tracks.OfType<AudioTrack>().Count() + 1}" };
            _ps.CommandStack.Execute(new DelegateCommand("Add audio track",
                () => _ps.Timeline.AddTrack(t), () => _ps.Timeline.RemoveTrack(t)));
        }

        // ---- Project ----
        [RelayCommand] private void NewProject() { _ps.NewProject(); StatusMessage = "New project."; }

        [RelayCommand]
        private async Task OpenProject()
        {
            var dlg = new OpenFileDialog { Filter = "Meftah Project|*.meftah|All|*.*" };
            if (dlg.ShowDialog() != true) return;
            await _ps.LoadAsync(dlg.FileName);
            App.RecentProjects.Add(dlg.FileName);
            StatusMessage = $"Opened {Path.GetFileName(dlg.FileName)}";
        }

        [RelayCommand]
        private async Task SaveProject()
        {
            var path = _ps.CurrentPath;
            if (string.IsNullOrEmpty(path))
            {
                var dlg = new SaveFileDialog { Filter = "Meftah Project|*.meftah", DefaultExt = "meftah", FileName = _ps.Settings.Name };
                if (dlg.ShowDialog() != true) return;
                path = dlg.FileName;
            }
            await _ps.SaveAsync(path);
            App.RecentProjects.Add(path);
            StatusMessage = $"Saved {Path.GetFileName(path)}";
        }

        [RelayCommand]
        private async Task SaveAs()
        {
            var dlg = new SaveFileDialog { Filter = "Meftah Project|*.meftah", DefaultExt = "meftah", FileName = _ps.Settings.Name };
            if (dlg.ShowDialog() != true) return;
            await _ps.SaveAsync(dlg.FileName);
            App.RecentProjects.Add(dlg.FileName);
            StatusMessage = $"Saved {Path.GetFileName(dlg.FileName)}";
        }

        // ---- Export (FFmpeg timeline export) ----
        [ObservableProperty] private bool _isExporting;
        [ObservableProperty] private double _exportProgress;

        [RelayCommand]
        private async Task Export()
        {
            if (IsExporting) return;

            if (!Meftah.Engine.Playback.FFmpegLocator.IsAvailable)
            {
                StatusMessage = "FFmpeg not found — place ffmpeg.exe/ffprobe.exe in an \"ffmpeg\" folder next to the app, or add them to PATH.";
                return;
            }
            if (_ps.Timeline.TotalDuration() <= TimeSpan.Zero)
            {
                StatusMessage = "Timeline is empty — nothing to export.";
                return;
            }

            var dlg = new SaveFileDialog
            {
                Title = "Export Video",
                Filter = "MP4 Video|*.mp4",
                DefaultExt = "mp4",
                FileName = string.IsNullOrWhiteSpace(_ps.Settings.Name) ? "export" : _ps.Settings.Name
            };
            if (dlg.ShowDialog() != true) return;

            IsExporting = true;
            ExportProgress = 0;
            StatusMessage = "Exporting… 0%";
            var progress = new Progress<double>(p =>
            {
                ExportProgress = p;
                StatusMessage = $"Exporting… {p:P0}";
            });

            try
            {
                var exporter = new Meftah.Engine.Export.TimelineExporter();
                await exporter.ExportAsync(_ps.Timeline, _ps.Settings, dlg.FileName, progress);
                StatusMessage = $"Exported: {Path.GetFileName(dlg.FileName)}";
            }
            catch (Exception ex)
            {
                StatusMessage = "Export failed: " + ex.Message;
            }
            finally
            {
                IsExporting = false;
            }
        }

        [RelayCommand]
        private void BackToDashboard()
        {
            var dashboard = new Views.DashboardWindow();
            // نفس ملاحظة OpenEditor في DashboardWindow: يجب تحديث MainWindow يدوياً
            // هنا أيضاً، وإلا فإن أي كود لاحق يعتمد على Application.Current.MainWindow
            // سيبقى يشير لنافذة المحرر التي أوشكنا على إغلاقها.
            Application.Current.MainWindow = dashboard;
            dashboard.Show();
            foreach (var w in Application.Current.Windows.OfType<Views.EditorWindow>().ToList())
                w.Close();
        }
    }
}