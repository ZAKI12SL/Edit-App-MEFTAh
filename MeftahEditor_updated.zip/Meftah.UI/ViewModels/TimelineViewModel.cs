using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using CommunityToolkit.Mvvm.ComponentModel;
using Meftah.Core.Commands;
using Meftah.Core.Models;

namespace Meftah.UI.ViewModels
{
    public partial class TimelineViewModel : ObservableObject
    {
        public Timeline Timeline { get; }
        public EditCommandStack CommandStack { get; }
        public ObservableCollection<Track> Tracks => Timeline.Tracks;
        public ObservableCollection<Marker> Markers => Timeline.Markers;

        [ObservableProperty] private double _zoom = 80;
        [ObservableProperty] private TimeSpan _playheadPosition;

        /// المقطع المحدد حالياً في التايم لاين (لعرضه في Effect Controls / Audio Mixer)
        [ObservableProperty] private Clip? _selectedClip;

        public event Action<TimeSpan>? PlayheadChanged;
        partial void OnPlayheadPositionChanged(TimeSpan value) => PlayheadChanged?.Invoke(value);

        private readonly List<Clip> _clipboard = new();

        public TimelineViewModel(Timeline timeline, EditCommandStack stack)
        { Timeline = timeline; CommandStack = stack; }

        public Track? TrackOf(Clip c) => Tracks.FirstOrDefault(t => t.Clips.Contains(c));

        /// هل يصح نقل هذا المقطع إلى هذا المسار؟ (فيديو↔مسار فيديو، صوت↔مسار صوت،
        /// والمسار غير مقفول). مركزية هذا الفحص هنا تسمح لأي أداة تحرير مستقبلية
        /// (سحب في التايم لاين، قائمة "Move to Track"، لصق...) باستخدام نفس القاعدة
        /// بدل تكرارها في كل مكان.
        public static bool CanMoveToTrack(Clip clip, Track track) =>
            !track.IsLocked &&
            ((clip is VideoClip && track is VideoTrack) || (clip is AudioClip && track is AudioTrack));

        public void AddMediaToTrack(MediaItem item, Track track)
        {
            if (track.IsLocked) return;
            var start = track.Clips.Count == 0 ? TimeSpan.Zero : track.Clips.Max(c => c.End);
            InsertAt(item, track, start);
        }

        public void InsertAt(MediaItem item, Track track, TimeSpan start)
        {
            if (track.IsLocked) return;
            var dur = item.Duration > TimeSpan.Zero ? item.Duration : TimeSpan.FromSeconds(5);
            Clip clip = track is AudioTrack
                ? new AudioClip { Name = item.FileName, Source = item, Start = start, Duration = dur }
                : new VideoClip { Name = item.FileName, Source = item, Start = start, Duration = dur };
            // عناصر Media Library المُولَّدة (Text/Shape/Path/Adjustment Layer/Color Matte)
            // تحتفظ بلونها المميز على المقطع الناتج بدل اللون الافتراضي للمسار.
            if (item.IsSynthetic && !string.IsNullOrEmpty(item.ColorHex))
                clip.ColorHex = item.ColorHex;
            CommandStack.Execute(new DelegateCommand("Add clip",
                () => track.AddClip(clip), () => track.RemoveClip(clip)));
        }

        public void Copy() => _clipboard.AddRange(Timeline.SelectedClips());

        public void PasteAtPlayhead()
        {
            if (_clipboard.Count == 0) return;
            var minStart = _clipboard.Min(c => c.Start);
            var pastes = _clipboard.Select(orig =>
            {
                var t = TrackOf(orig) ?? Tracks.FirstOrDefault();
                if (t == null || t.IsLocked) return (null, null);
                var copy = orig.ShallowClone();
                copy.Start = PlayheadPosition + (orig.Start - minStart);
                return ((Clip?)copy, (Track?)t);
            }).Where(x => x.Item1 != null).ToList();

            CommandStack.Execute(new DelegateCommand("Paste",
                () => { Timeline.ClearSelection(); foreach (var (c,t) in pastes) { t!.AddClip(c!); c!.IsSelected=true; } },
                () => { foreach (var (c,t) in pastes) t!.RemoveClip(c!); }));
        }

        public void Duplicate()
        {
            var sel = Timeline.SelectedClips().Select(c => (c, TrackOf(c))).Where(x => x.Item2 != null && !x.Item2.IsLocked).ToList();
            if (sel.Count == 0) return;
            var dups = sel.Select(x => { var copy=x.c.ShallowClone(); copy.Start=x.c.End; return (copy,x.Item2!); }).ToList();
            CommandStack.Execute(new DelegateCommand("Duplicate",
                () => { Timeline.ClearSelection(); foreach (var (c,t) in dups) { t.AddClip(c); c.IsSelected=true; } },
                () => { foreach (var (c,t) in dups) t.RemoveClip(c); }));
        }

        public void Delete(bool ripple)
        {
            var sel = Timeline.SelectedClips().Select(c => (c, TrackOf(c))).Where(x => x.Item2 != null && !x.Item2.IsLocked).ToList();
            if (sel.Count == 0) return;
            if (SelectedClip != null && sel.Any(x => x.c == SelectedClip)) SelectedClip = null;
            CommandStack.Execute(new DelegateCommand(ripple ? "Ripple delete" : "Delete",
                () => { foreach (var (c,t) in sel) { t!.RemoveClip(c); if(ripple) t.RippleShift(c.Start, -c.Duration); } },
                () => { foreach (var (c,t) in sel) { if(ripple) t!.RippleShift(c.Start, c.Duration); t!.AddClip(c); } }));
        }

        public void AddMarkerAt(TimeSpan time)
        {
            var m = new Marker { Time = time, Label = $"Marker {Markers.Count+1}" };
            CommandStack.Execute(new DelegateCommand("Add marker", () => Markers.Add(m), () => Markers.Remove(m)));
        }

        public void SetColor(string hex)
        {
            var sel = Timeline.SelectedClips().ToList();
            if (sel.Count == 0) return;
            var prev = sel.Select(c => (c, old: c.ColorHex)).ToList();
            CommandStack.Execute(new DelegateCommand("Set color",
                () => { foreach (var (c,_) in prev) c.ColorHex=hex; },
                () => { foreach (var (c,old) in prev) c.ColorHex=old; }));
        }
    }
}