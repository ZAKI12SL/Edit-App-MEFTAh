using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using Meftah.Core.Models;
using Meftah.UI.ViewModels;

namespace Meftah.UI.Controls
{
    public partial class TimelineControl : UserControl
    {
        public static readonly DependencyProperty ViewModelProperty =
            DependencyProperty.Register(nameof(ViewModel), typeof(TimelineViewModel),
                typeof(TimelineControl), new PropertyMetadata(null));

        public TimelineViewModel? ViewModel
        {
            get => (TimelineViewModel?)GetValue(ViewModelProperty);
            set => SetValue(ViewModelProperty, value);
        }

        private const double TrackH = 56;
        private enum DragMode { None, Move, TrimL, TrimR }
        private DragMode _drag;
        private Clip? _dragClip;
        private Point _dragOrigin;
        private TimeSpan _origStart, _origDur, _origSourceIn;
        // يحفظ لكل مقطع مسحوب: المقطع نفسه، زمن بدايته الأصلي، وفهرس مساره
        // الأصلي — الفهرس الأصلي لازم لحساب أي مسار "يهبط" فيه المقطع عمودياً
        // أثناء السحب (نقل بين المسارات)، وليس فقط إزاحته أفقياً كما كان سابقاً.
        private List<(Clip c, TimeSpan s, int trackIdx)>? _dragGroup;
        // فرق عدد صفوف المسار (موجب للأسفل، سالب للأعلى) المُحسوب حياً أثناء
        // السحب العمودي — يُستخدم لمعاينة المقطع في مساره الجديد قبل تثبيت
        // النقل الفعلي عند رفع الفأرة.
        private int _dragTrackDelta;

        // ~60fps بدل ~33fps: يجعل خط المؤشر أثناء التشغيل والتكبير/التصغير
        // أكثر سلاسة بدل قفزه كل 30ms.
        private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(16) };

        public TimelineControl() { InitializeComponent(); _timer.Tick += (_, _) => Redraw(); }

        private void OnLoaded(object s, RoutedEventArgs e) => _timer.Start();
        private void OnUnloaded(object s, RoutedEventArgs e) => _timer.Stop();

        // ─── Redraw ───────────────────────────────────────────────────
        private void Redraw()
        {
            var vm = ViewModel; if (vm == null) return;
            double pps = Math.Max(5, vm.Zoom);
            double totalSec = Math.Max(vm.Timeline.TotalDuration().TotalSeconds + 30,
                                       LanesScroll.ViewportWidth / pps + 5);
            double cw = totalSec * pps;
            double ch = Math.Max(vm.Tracks.Count * TrackH, LanesScroll.ViewportHeight);

            DrawRuler(vm, pps, cw);
            DrawHeaders(vm);
            DrawLanes(vm, pps, cw, ch);

            DurationLabel.Text = "Duration: " + FormatShort(vm.Timeline.TotalDuration());
        }

        private void DrawRuler(TimelineViewModel vm, double pps, double cw)
        {
            RulerCanvas.Children.Clear();
            RulerCanvas.Width = cw;
            double interval = TickInterval(pps);
            for (double t = 0; t <= cw / pps + interval; t += interval)
            {
                double x = t * pps;
                RulerCanvas.Children.Add(new Line { X1=x,X2=x,Y1=14,Y2=28,
                    Stroke=Brushes.DimGray, StrokeThickness=1 });
                var tb = new TextBlock { Text=FormatShort(TimeSpan.FromSeconds(t)),
                    Foreground=Brushes.Gray, FontSize=9 };
                Canvas.SetLeft(tb, x+2); Canvas.SetTop(tb, 1);
                RulerCanvas.Children.Add(tb);
            }
            foreach (var mk in vm.Markers)
            {
                double x = mk.Time.TotalSeconds * pps;
                RulerCanvas.Children.Add(new Polygon
                {
                    Points = new PointCollection { new(x,0),new(x+8,0),new(x,8) },
                    Fill = HexBrush(mk.ColorHex), ToolTip = mk.Label
                });
            }
            double phx = vm.PlayheadPosition.TotalSeconds * pps;
            RulerCanvas.Children.Add(new Polygon
            {
                Points = new PointCollection { new(phx-6,0),new(phx+6,0),new(phx,10) },
                Fill = Brushes.OrangeRed
            });
        }

        private void DrawHeaders(TimelineViewModel vm)
        {
            HeaderPanel.Children.Clear();
            foreach (var track in vm.Tracks)
            {
                var tr = track;
                var border = new Border
                {
                    Height = TrackH,
                    Background = new SolidColorBrush(Color.FromRgb(0x0E,0x13,0x18)),
                    BorderBrush = new SolidColorBrush(Color.FromRgb(0x1E,0x2A,0x38)),
                    BorderThickness = new Thickness(0,0,1,1)
                };
                var grid = new Grid { Margin = new Thickness(8,4,8,4) };
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                var name = new TextBlock { Text=track.Name, FontWeight=FontWeights.SemiBold,
                    FontSize=12, Foreground=Brushes.White, TextTrimming=TextTrimming.CharacterEllipsis };
                Grid.SetRow(name, 0); grid.Children.Add(name);
                var btns = new StackPanel { Orientation=Orientation.Horizontal, Margin=new Thickness(0,4,0,0) };
                btns.Children.Add(MakeBtn(track.IsLocked?"🔒":"🔓", track.IsLocked, ()=>tr.IsLocked=!tr.IsLocked));
                btns.Children.Add(MakeBtn(track.IsHidden?"🚫":"👁", track.IsHidden, ()=>tr.IsHidden=!tr.IsHidden));
                btns.Children.Add(MakeBtn(track.IsMuted?"🔇":"🔊", track.IsMuted, ()=>tr.IsMuted=!tr.IsMuted));
                Grid.SetRow(btns, 1); grid.Children.Add(btns);
                border.Child = grid;
                HeaderPanel.Children.Add(border);
            }
        }

        private static Button MakeBtn(string txt, bool active, Action onClick)
        {
            var b = new Button
            {
                Content=txt, Width=24, Height=20, Padding=new Thickness(0),
                Margin=new Thickness(0,0,3,0), BorderThickness=new Thickness(0),
                FontSize=11, Cursor=Cursors.Hand,
                Background=active
                    ? new SolidColorBrush(Color.FromRgb(0x25,0x63,0xEB))
                    : new SolidColorBrush(Color.FromRgb(0x1C,0x24,0x30)),
                Foreground=Brushes.White
            };
            b.Click += (_,_) => onClick();
            return b;
        }

        private void DrawLanes(TimelineViewModel vm, double pps, double cw, double ch)
        {
            LanesCanvas.Children.Clear();
            LanesCanvas.Width = cw; LanesCanvas.Height = ch;

            // أثناء السحب العمودي، أي صفوف هي الوجهة الحالية (المعاينة الحية)
            // لمقاطع المجموعة المسحوبة؟ تُستخدم لتظليل تلك المسارات.
            HashSet<int>? dropTargetRows = null;
            if (_drag==DragMode.Move && _dragGroup!=null && _dragTrackDelta!=0)
            {
                dropTargetRows = new HashSet<int>();
                foreach (var g in _dragGroup)
                    dropTargetRows.Add(ResolveTargetTrackIndex(vm, g.trackIdx, g.c, _dragTrackDelta));
            }

            for (int i = 0; i < vm.Tracks.Count; i++)
            {
                var track = vm.Tracks[i];
                double y = i * TrackH;
                bool isDropTarget = dropTargetRows != null && dropTargetRows.Contains(i);
                var lane = new Rectangle
                {
                    Width=cw, Height=TrackH, Opacity=track.IsHidden?0.3:1,
                    Fill = isDropTarget
                        ? new SolidColorBrush(Color.FromArgb(0x33,0x25,0x63,0xEB))
                        : new SolidColorBrush(i%2==0
                            ? Color.FromRgb(0x0C,0x10,0x17)
                            : Color.FromRgb(0x09,0x0D,0x13))
                };
                Canvas.SetLeft(lane,0); Canvas.SetTop(lane,y);
                LanesCanvas.Children.Add(lane);

                // divider
                var div = new Line { X1=0,X2=cw,Y1=y+TrackH-1,Y2=y+TrackH-1,
                    Stroke=new SolidColorBrush(Color.FromRgb(0x1E,0x2A,0x38)), StrokeThickness=1 };
                LanesCanvas.Children.Add(div);
            }

            // ترسم المقاطع في تمريرة منفصلة (بعد كل الخلفيات) حتى يبقى المقطع
            // المسحوب دائماً ظاهراً فوق أي مسار "يعبره" أثناء التنقل عمودياً.
            for (int i = 0; i < vm.Tracks.Count; i++)
            {
                var track = vm.Tracks[i];
                foreach (var clip in track.Clips)
                {
                    bool isDragging = false;
                    int rowIndex = i;
                    if (_drag==DragMode.Move && _dragGroup!=null)
                    {
                        var member = _dragGroup.FirstOrDefault(g => ReferenceEquals(g.c, clip));
                        if (member.c != null)
                        {
                            isDragging = true;
                            rowIndex = ResolveTargetTrackIndex(vm, member.trackIdx, clip, _dragTrackDelta);
                        }
                    }
                    double rowY = rowIndex * TrackH;

                    double cx = clip.Start.TotalSeconds * pps;
                    double cw2 = Math.Max(4, clip.Duration.TotalSeconds * pps);
                    var bg = HexBrush(clip.ColorHex);
                    var clipBorder = new Border
                    {
                        Width=cw2, Height=TrackH-8,
                        CornerRadius=new CornerRadius(4),
                        Background=bg,
                        BorderBrush=clip.IsSelected?Brushes.White:Brushes.Black,
                        BorderThickness=new Thickness(clip.IsSelected?2:1),
                        Opacity = track.IsHidden ? 0.4 : (isDragging ? 0.85 : 1),
                        Tag=clip, ClipToBounds=true,
                        Cursor=track.IsLocked?Cursors.No:Cursors.SizeAll
                    };
                    var lbl = new TextBlock
                    {
                        Text=clip.Name, Foreground=Brushes.White, FontSize=10,
                        Margin=new Thickness(6,3,4,0), TextTrimming=TextTrimming.CharacterEllipsis,
                        IsHitTestVisible=false
                    };
                    clipBorder.Child = lbl;
                    Canvas.SetLeft(clipBorder, cx);
                    Canvas.SetTop(clipBorder, rowY+4);
                    if (isDragging) Panel.SetZIndex(clipBorder, 10);
                    LanesCanvas.Children.Add(clipBorder);
                }
            }
            // Playhead line
            double phx2 = vm.PlayheadPosition.TotalSeconds * pps;
            LanesCanvas.Children.Add(new Line { X1=phx2,X2=phx2,Y1=0,Y2=ch,
                Stroke=Brushes.OrangeRed, StrokeThickness=1.5 });
            // Marker lines
            foreach (var mk in vm.Markers)
            {
                double mx = mk.Time.TotalSeconds * pps;
                LanesCanvas.Children.Add(new Line { X1=mx,X2=mx,Y1=0,Y2=ch,
                    Stroke=HexBrush(mk.ColorHex), StrokeThickness=1,
                    StrokeDashArray=new DoubleCollection{4,3} });
            }
        }

        // ─── Hit test ────────────────────────────────────────────────
        private static (FrameworkElement el, Clip clip)? HitClip(DependencyObject? src)
        {
            while (src != null)
            {
                if (src is FrameworkElement fe && fe.Tag is Clip c) return (fe, c);
                src = VisualTreeHelper.GetParent(src);
            }
            return null;
        }

        // ─── Mouse ───────────────────────────────────────────────────
        private void LanesMouseDown(object s, MouseButtonEventArgs e)
        {
            var vm = ViewModel; if (vm==null) return;
            Focus();
            var hit = HitClip(e.OriginalSource as DependencyObject);
            if (hit == null)
            {
                if (!Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) { vm.Timeline.ClearSelection(); vm.SelectedClip = null; }
                return;
            }
            var (el, clip) = hit.Value;
            var track = vm.TrackOf(clip); if (track!=null && track.IsLocked) return;
            bool ctrl = Keyboard.Modifiers.HasFlag(ModifierKeys.Control);
            if (!clip.IsSelected) { if (!ctrl) vm.Timeline.ClearSelection(); clip.IsSelected=true; }
            vm.SelectedClip = clip;
            double lx = e.GetPosition(el).X;
            _drag = lx<=6 ? DragMode.TrimL : lx>=el.ActualWidth-6 ? DragMode.TrimR : DragMode.Move;
            _dragClip=clip; _dragOrigin=e.GetPosition(LanesCanvas);
            _origStart=clip.Start; _origDur=clip.Duration; _origSourceIn=clip.SourceIn;
            _dragTrackDelta = 0;
            _dragGroup = vm.Timeline.SelectedClips()
                .Select(c => (c, s: c.Start, trackIdx: vm.Tracks.IndexOf(vm.TrackOf(c)!)))
                .ToList();
            LanesCanvas.CaptureMouse(); e.Handled=true;
        }

        private void LanesMouseMove(object s, MouseEventArgs e)
        {
            if (_dragClip==null||_drag==DragMode.None||ViewModel==null) return;
            if (e.LeftButton!=MouseButtonState.Pressed) return;
            double dx = (e.GetPosition(LanesCanvas).X - _dragOrigin.X) / Math.Max(5, ViewModel.Zoom);
            if (_drag==DragMode.Move)
            {
                var delta = TimeSpan.FromSeconds(dx);
                foreach (var (c,os,_) in _dragGroup!)
                    c.Start = os+delta < TimeSpan.Zero ? TimeSpan.Zero : os+delta;

                // إزاحة الصفوف العمودية: تُقرّب لأقرب عدد صحيح من ارتفاعات
                // المسارات حتى لا يتأرجح المقطع بين مسارين لأقل حركة فأرة.
                double dyPix = e.GetPosition(LanesCanvas).Y - _dragOrigin.Y;
                _dragTrackDelta = (int)Math.Round(dyPix / TrackH);
            }
            else if (_drag==DragMode.TrimL)
            {
                var ns = _origStart+TimeSpan.FromSeconds(dx);
                if (ns<TimeSpan.Zero) ns=TimeSpan.Zero;
                var latest = _origStart+_origDur-TimeSpan.FromSeconds(0.1);
                if (ns>latest) ns=latest;
                // اسحب نقطة "in" داخل المصدر بنفس مقدار إزاحة الحافة اليسرى، حتى
                // يبقى الجزء المعروض من الفيديو/الصوت متطابقاً مع موضعه الحقيقي في
                // الملف الأصلي بدل إعادة تشغيله من بدايته دائماً.
                var shift = ns - _origStart;
                var newSourceIn = _origSourceIn + shift;
                if (newSourceIn < TimeSpan.Zero) { newSourceIn = TimeSpan.Zero; ns = _origStart - _origSourceIn; }
                _dragClip.SourceIn = newSourceIn;
                _dragClip.Duration=_origStart+_origDur-ns;
                _dragClip.Start=ns;
            }
            else
            {
                var nd = _origDur+TimeSpan.FromSeconds(dx);
                if (nd<TimeSpan.FromSeconds(0.1)) nd=TimeSpan.FromSeconds(0.1);
                _dragClip.Duration=nd;
            }
        }

        private void LanesMouseUp(object s, MouseButtonEventArgs e)
        {
            var vmUp = ViewModel;
            if (_dragClip!=null && vmUp!=null && _drag==DragMode.Move && _dragGroup!=null)
            {
                // لكل مقطع مسحوب: المسار الأصلي، والمسار الهدف المحسوم بنفس منطق
                // المعاينة الحية (ResolveTargetTrackIndex) — إن كان الهدف غير صالح
                // (نوع غير مطابق أو مسار مقفول) يعود تلقائياً لمساره الأصلي.
                var moves = _dragGroup.Select(g =>
                {
                    var fromTrack = vmUp.Tracks[Math.Min(g.trackIdx, vmUp.Tracks.Count-1)];
                    var targetIdx = ResolveTargetTrackIndex(vmUp, g.trackIdx, g.c, _dragTrackDelta);
                    var toTrack = vmUp.Tracks[targetIdx];
                    return (clip: g.c, oldStart: g.s, newStart: g.c.Start, fromTrack, toTrack);
                }).Where(m => m.newStart != m.oldStart || !ReferenceEquals(m.fromTrack, m.toTrack)).ToList();

                if (moves.Count>0)
                    ViewModel!.CommandStack.Execute(new Meftah.Core.Commands.DelegateCommand("Move clip(s)",
                        () => { foreach (var m in moves)
                                { if (!ReferenceEquals(m.fromTrack,m.toTrack)) { m.fromTrack.RemoveClip(m.clip); m.toTrack.AddClip(m.clip); }
                                  m.clip.Start = m.newStart; } },
                        () => { foreach (var m in moves)
                                { if (!ReferenceEquals(m.fromTrack,m.toTrack)) { m.toTrack.RemoveClip(m.clip); m.fromTrack.AddClip(m.clip); }
                                  m.clip.Start = m.oldStart; } }));
            }
            _dragClip=null; _drag=DragMode.None; _dragGroup=null; _dragTrackDelta=0;
            if (LanesCanvas.IsMouseCaptured) LanesCanvas.ReleaseMouseCapture();
        }

        // ─── Right-click menu ────────────────────────────────────────
        private void LanesRightClick(object s, MouseButtonEventArgs e)
        {
            var vm = ViewModel; if (vm==null) return;
            var pos = e.GetPosition(LanesCanvas);
            var t = TimeSpan.FromSeconds(Math.Max(0, pos.X / Math.Max(5,vm.Zoom)));
            var hit = HitClip(e.OriginalSource as DependencyObject);
            var menu = new ContextMenu();
            if (hit!=null)
            {
                var clip=hit.Value.clip;
                if (!clip.IsSelected) { vm.Timeline.ClearSelection(); clip.IsSelected=true; }
                vm.SelectedClip = clip;
                menu.Items.Add(MI("Duplicate  Ctrl+D", ()=>vm.Duplicate()));
                menu.Items.Add(MI("Copy  Ctrl+C", ()=>vm.Copy()));
                menu.Items.Add(new Separator());
                menu.Items.Add(MI("Delete  Del", ()=>vm.Delete(false)));
                menu.Items.Add(MI("Ripple Delete  Shift+Del", ()=>vm.Delete(true)));
                menu.Items.Add(new Separator());
                var colorSub = new MenuItem { Header="Clip Color" };
                foreach (var hex in new[]{"#2563EB","#DC2626","#059669","#D97706","#7C3AED","#DB2777","#0891B2"})
                {
                    var h=hex; var mi=new MenuItem { Header=h,
                        Icon=new Border{Width=12,Height=12,Background=HexBrush(h)} };
                    mi.Click+=(_,_)=>vm.SetColor(h);
                    colorSub.Items.Add(mi);
                }
                menu.Items.Add(colorSub);
            }
            else menu.Items.Add(MI("Paste  Ctrl+V", ()=>vm.PasteAtPlayhead()));
            menu.Items.Add(new Separator());
            menu.Items.Add(MI("Add Marker Here", ()=>vm.AddMarkerAt(t)));
            menu.PlacementTarget=LanesCanvas; menu.IsOpen=true; e.Handled=true;
        }

        private static MenuItem MI(string h, Action a)
        { var m=new MenuItem{Header=h}; m.Click+=(_,_)=>a(); return m; }

        // ─── Ruler click → seek ──────────────────────────────────────
        private void RulerClick(object s, MouseButtonEventArgs e)
        {
            if (ViewModel==null) return;
            ViewModel.PlayheadPosition = TimeSpan.FromSeconds(
                Math.Max(0, e.GetPosition(RulerCanvas).X / Math.Max(5,ViewModel.Zoom)));
        }

        // ─── Zoom slider ─────────────────────────────────────────────
        /// يحافظ على الزمن الظاهر في منتصف نافذة العرض ثابتاً أثناء تغيير
        /// التكبير، بدل أن "تقفز" التايم لاين يميناً/يساراً مع كل حركة صغيرة
        /// للمؤشر — هذا هو المقصود بجعل التكبير أكثر سلاسة.
        private void ZoomChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (ViewModel==null) return;
            double oldPps = Math.Max(5, e.OldValue);
            double centerTime = (LanesScroll.HorizontalOffset + LanesScroll.ViewportWidth/2) / oldPps;

            ViewModel.Zoom = e.NewValue;
            Redraw(); // يحدّث عرض LanesCanvas فوراً على مقياس التكبير الجديد قبل ضبط التمرير

            double newPps = Math.Max(5, e.NewValue);
            double newOffset = centerTime*newPps - LanesScroll.ViewportWidth/2;
            LanesScroll.ScrollToHorizontalOffset(Math.Max(0, newOffset));
        }

        // ─── Scroll sync ─────────────────────────────────────────────
        private void LanesScrollChanged(object s, ScrollChangedEventArgs e)
        {
            RulerScroll.ScrollToHorizontalOffset(e.HorizontalOffset);
            HeaderScroll.ScrollToVerticalOffset(e.VerticalOffset);
        }

        // ─── Mouse wheel over the timeline ─────────────────────────────
        // السلوك الافتراضي القديم لعجلة الفأرة (تمرير عمودي فقط عبر
        // ScrollViewer) غير عملي على تايم لاين عريض أفقياً. السلوك الجديد،
        // المطابق لمحررات الفيديو المعروفة:
        //  • عجلة عادية        → تمرير أفقي (يتنقل عبر زمن التايم لاين).
        //  • Ctrl + عجلة       → تكبير/تصغير مُثبَّت على موضع الفأرة (النقطة
        //                        الزمنية تحت المؤشر تبقى ثابتة مكانياً).
        //  • Shift + عجلة      → تمرير عمودي بين المسارات (السلوك الافتراضي
        //                        القديم، محفوظ لمن يحتاج التنقل بين المسارات
        //                        بالعجلة بدل شريط التمرير).
        private void LanesPreviewMouseWheel(object s, MouseWheelEventArgs e)
        {
            var vm = ViewModel; if (vm == null) return;

            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
            {
                double oldPps = Math.Max(5, vm.Zoom);
                double mouseX = e.GetPosition(LanesCanvas).X;
                double anchorTime = mouseX / oldPps;

                double step = Math.Max(4, vm.Zoom * 0.12);
                double newZoom = vm.Zoom + (e.Delta > 0 ? step : -step);
                newZoom = Math.Max(ZoomSlider.Minimum, Math.Min(ZoomSlider.Maximum, newZoom));

                ZoomSlider.Value = newZoom; // يستدعي ZoomChanged (تكبير مُمركَز على منتصف الشاشة) + Redraw()

                // نُصحّح إزاحة التمرير بعد ذلك لتُبقي بالضبط نقطة الزمن التي كانت
                // تحت الفأرة في نفس مكانها، بدل مركز الشاشة كما تفعل ZoomChanged.
                double newPps = Math.Max(5, vm.Zoom);
                double newOffset = anchorTime * newPps - mouseX;
                LanesScroll.ScrollToHorizontalOffset(Math.Max(0, newOffset));
                e.Handled = true;
                return;
            }

            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
                return; // يترك السلوك الافتراضي (تمرير عمودي بين المسارات) يعمل

            // العجلة العادية: تمرير أفقي عبر زمن التايم لاين بدل التمرير العمودي.
            LanesScroll.ScrollToHorizontalOffset(Math.Max(0, LanesScroll.HorizontalOffset - e.Delta));
            e.Handled = true;
        }

        // ─── Drag & drop from media bin ──────────────────────────────
        private void LanesDragOver(object s, DragEventArgs e)
        { e.Effects = e.Data.GetDataPresent(typeof(MediaItem)) ? DragDropEffects.Copy : DragDropEffects.None; e.Handled=true; }

        private void LanesDrop(object s, DragEventArgs e)
        {
            if (ViewModel==null) return;
            if (e.Data.GetData(typeof(MediaItem)) is not MediaItem item) return;
            var pos = e.GetPosition(LanesCanvas);
            int idx = (int)(pos.Y / TrackH);
            if (idx<0||idx>=ViewModel.Tracks.Count) return;
            var track = ViewModel.Tracks[idx];
            var t = TimeSpan.FromSeconds(Math.Max(0, pos.X / Math.Max(5,ViewModel.Zoom)));
            ViewModel.InsertAt(item, track, t);
        }

        // ─── Track-switch drag helper ──────────────────────────────────
        /// يحسب فهرس صف المسار الذي يجب رسم/إسقاط هذا المقطع فيه أثناء السحب
        /// العمودي: يبدأ من فهرسه الأصلي مضافاً إليه فرق الصفوف الحالي، يُقيَّد
        /// ضمن حدود قائمة المسارات، ثم يُتحقَّق أن المسار الناتج متوافق النوع
        /// مع المقطع وغير مقفول (عبر TimelineViewModel.CanMoveToTrack). إن لم
        /// يكن كذلك يعود للمسار الأصلي — فيبقى المقطع في مكانه بدل "السقوط"
        /// في مسار غير صالح.
        private static int ResolveTargetTrackIndex(TimelineViewModel vm, int originIdx, Clip clip, int trackDelta)
        {
            if (vm.Tracks.Count == 0) return originIdx;
            originIdx = Math.Max(0, Math.Min(vm.Tracks.Count - 1, originIdx));
            if (trackDelta == 0) return originIdx;
            int target = Math.Max(0, Math.Min(vm.Tracks.Count - 1, originIdx + trackDelta));
            return TimelineViewModel.CanMoveToTrack(clip, vm.Tracks[target]) ? target : originIdx;
        }

        // ─── Helpers ─────────────────────────────────────────────────
        private static Brush HexBrush(string hex)
        { try { return (Brush)new BrushConverter().ConvertFromString(hex)!; } catch { return Brushes.SlateBlue; } }

        private static double TickInterval(double pps)
        {
            foreach (var s in new[]{0.5,1,2,5,10,15,30,60,120,300,600})
                if (s*pps>=70) return s;
            return 600;
        }

        private static string FormatShort(TimeSpan t) =>
            t.TotalHours>=1 ? $"{(int)t.TotalHours}:{t.Minutes:00}:{t.Seconds:00}" : $"{t.Minutes:00}:{t.Seconds:00}";
    }
}