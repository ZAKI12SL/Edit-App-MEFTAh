using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Meftah.UI.Converters
{
    /// يُظهر العنصر (Visible) إن كانت القيمة غير Null، ويخفيه (Collapsed) إن كانت Null
    public sealed class NullToCollapsedConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object parameter, CultureInfo culture)
            => value == null ? Visibility.Collapsed : Visibility.Visible;
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }

    /// عكس السابق: يُظهر العنصر فقط عندما تكون القيمة Null (مثال: "لا يوجد مقطع محدد")
    public sealed class NullToVisibleConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object parameter, CultureInfo culture)
            => value == null ? Visibility.Visible : Visibility.Collapsed;
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }
}
